package com.tim.clcalendar

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val ClOrange = Color(0xFFE17D5E)
val WeekendRed = Color(0xFFE5614A)
val HolidayRed = WeekendRed.copy(alpha = 0.6f)

private val LightColors = lightColorScheme(
    primary = ClOrange,
    onPrimary = Color.White,
    background = Color(0xFFF7F4EE),
    onBackground = Color(0xFF1F1E1D),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1F1E1D),
    surfaceVariant = Color(0xFFF5F1E9),
    onSurfaceVariant = Color(0xFF6B6963),
    outline = Color(0xFFE2DDD1),
)

private val DarkColors = darkColorScheme(
    primary = ClOrange,
    onPrimary = Color.White,
    background = Color(0xFF121210),
    onBackground = Color(0xFFF2EFEA),
    surface = Color(0xFF1E1C1A),
    onSurface = Color(0xFFF2EFEA),
    surfaceVariant = Color(0xFF171614),
    onSurfaceVariant = Color(0xFF9C978F),
    outline = Color(0xFF2F2D2A),
)

@Composable
fun ClTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content,
    )
}
