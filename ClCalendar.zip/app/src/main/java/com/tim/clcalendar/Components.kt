package com.tim.clcalendar

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

val RU: Locale = Locale.forLanguageTag("ru")
val WEEKDAYS = listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")

fun fmt(min: Int) = "%02d:%02d".format(min / 60, min % 60)

fun barColor(n: Note): Color = BarColors[(n.id % BarColors.size).toInt()]

fun dayTitle(d: LocalDate): String =
    d.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", RU)).replaceFirstChar { it.uppercase() }

fun eventsCount(n: Int): String {
    if (n == 0) return "нет событий"
    val m10 = n % 10
    val m100 = n % 100
    val word = when {
        m100 in 11..14 -> "событий"
        m10 == 1 -> "событие"
        m10 in 2..4 -> "события"
        else -> "событий"
    }
    return "$n $word"
}

fun notesOf(state: NotesState, d: LocalDate): List<Note> =
    state.notes
        .filter { it.epochDay == d.toEpochDay() }
        .sortedBy { if (it.remindMin < 0) -1 else it.remindMin }

@Composable
fun Arrow(label: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, fontSize = 30.sp, color = MaterialTheme.colorScheme.onBackground)
    }
}

@Composable
fun DayHeader(day: LocalDate, count: Int) {
    val c = MaterialTheme.colorScheme
    val holiday = Holidays.name(day)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Column(Modifier.weight(1f)) {
            Text(dayTitle(day), fontSize = 20.sp, fontWeight = FontWeight.Bold, color = c.onBackground)
            if (holiday != null) {
                Text(holiday, fontSize = 13.sp, color = weekendColor)
            }
        }
        Text(eventsCount(count), fontSize = 14.sp, color = c.onSurfaceVariant)
    }
}

@Composable
fun EventRow(note: Note, onClick: () -> Unit) {
    val c = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.width(56.dp)) {
            if (note.remindMin >= 0) {
                Text(fmt(note.remindMin), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = c.onBackground)
            } else {
                Text("Весь день", fontSize = 12.sp, color = c.onSurfaceVariant)
            }
        }
        Box(
            Modifier
                .width(4.dp)
                .height(44.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(barColor(note))
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                note.text,
                fontSize = 17.sp,
                fontWeight = FontWeight.SemiBold,
                color = c.onBackground,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                if (note.remindMin >= 0) "Напоминание · " + fmt(note.remindMin) else "Заметка",
                fontSize = 14.sp,
                color = c.onSurfaceVariant,
            )
        }
    }
}

@Composable
fun EmptyDay(modifier: Modifier = Modifier) {
    val c = MaterialTheme.colorScheme
    Column(
        modifier
            .fillMaxWidth()
            .padding(vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Нет событий", fontSize = 17.sp, color = c.onBackground)
        Text("Отличный день!", fontSize = 14.sp, color = c.onSurfaceVariant)
    }
}

fun nextEvent(state: NotesState, today: LocalDate, nowMin: Int): Note? {
    val td = today.toEpochDay()
    return state.notes
        .filter { it.epochDay > td || (it.epochDay == td && (it.remindMin < 0 || it.remindMin >= nowMin)) }
        .minWithOrNull(
            compareBy<Note> { it.epochDay }.thenBy { if (it.remindMin < 0) -1 else it.remindMin }
        )
}

private fun daysWord(n: Int): String {
    val m10 = n % 10
    val m100 = n % 100
    return when {
        m100 in 11..14 -> "дней"
        m10 == 1 -> "день"
        m10 in 2..4 -> "дня"
        else -> "дней"
    }
}

@Composable
fun UpcomingCard(note: Note, today: LocalDate, onClick: () -> Unit) {
    val c = MaterialTheme.colorScheme
    val date = LocalDate.ofEpochDay(note.epochDay)
    val diff = (note.epochDay - today.toEpochDay()).toInt()
    val dayText = when (diff) {
        0 -> "Сегодня"
        1 -> "Завтра"
        else -> date.format(DateTimeFormatter.ofPattern("d MMMM, EEEE", RU))
    }
    val whenText = dayText + (if (note.remindMin >= 0) " · " + fmt(note.remindMin) else "")
    val badge = when (diff) {
        0 -> "сегодня"
        1 -> "завтра"
        else -> "через $diff " + daysWord(diff)
    }
    val shape = RoundedCornerShape(18.dp)

    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Text("Ближайшее событие", fontSize = 12.sp, color = c.onSurfaceVariant)
        Spacer(Modifier.height(6.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(c.surface)
                .border(1.dp, c.outline, shape)
                .clickable(onClick = onClick)
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .width(4.dp)
                    .height(44.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(barColor(note))
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    note.text,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = c.onBackground,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(whenText, fontSize = 13.sp, color = c.onSurfaceVariant)
            }
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(ClOrange.copy(alpha = 0.16f))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(badge, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = ClOrange)
            }
        }
    }
}
