package com.tim.clcall

import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager

object Dialer {
    fun isDefault(ctx: Context): Boolean = try {
        ctx.getSystemService(TelecomManager::class.java).defaultDialerPackage == ctx.packageName
    } catch (_: Exception) {
        false
    }

    fun roleIntent(ctx: Context): Intent? {
        return if (Build.VERSION.SDK_INT >= 29) {
            val rm = ctx.getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_DIALER)) {
                rm.createRequestRoleIntent(RoleManager.ROLE_DIALER)
            } else null
        } else {
            Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
                .putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, ctx.packageName)
        }
    }

    /** SIM-карты, из которых надо выбирать (пусто, если выбор не нужен) */
    fun pickableAccounts(ctx: Context): List<PhoneAccountHandle> {
        return try {
            val tm = ctx.getSystemService(TelecomManager::class.java)
            val list = tm.callCapablePhoneAccounts
            if (list.size > 1 && tm.getDefaultOutgoingPhoneAccount("tel") == null) list else emptyList()
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun simLabel(ctx: Context, h: PhoneAccountHandle, index: Int): String {
        return try {
            val tm = ctx.getSystemService(TelecomManager::class.java)
            tm.getPhoneAccount(h)?.label?.toString()?.takeIf { it.isNotBlank() } ?: "SIM ${index + 1}"
        } catch (_: Exception) {
            "SIM ${index + 1}"
        }
    }

    fun place(ctx: Context, number: String, account: PhoneAccountHandle?) {
        val uri = Uri.fromParts("tel", number, null)
        val extras = Bundle()
        if (account != null) extras.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, account)
        try {
            ctx.getSystemService(TelecomManager::class.java).placeCall(uri, extras)
        } catch (_: SecurityException) {
            return
        }
        if (isDefault(ctx)) {
            ctx.startActivity(
                Intent(ctx, InCallActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
        }
    }
}
