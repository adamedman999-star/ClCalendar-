package com.tim.clcall

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.*

@Composable
fun Ico(
    res: Int,
    size: Dp = 24.dp,
    tint: Color = LocalContentColor.current,
    modifier: Modifier = Modifier,
) {
    Image(
        painter = painterResource(res),
        contentDescription = null,
        modifier = modifier.size(size),
        colorFilter = ColorFilter.tint(tint),
    )
}

@Composable
fun CircleBtn(
    res: Int,
    bg: Color,
    tint: Color,
    size: Dp = 44.dp,
    icon: Dp = 22.dp,
    onClick: () -> Unit,
) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(bg)
            .clClick(onClick),
        contentAlignment = Alignment.Center,
    ) {
        Ico(res, icon, tint)
    }
}

@Composable
fun Avatar(name: String?, size: Dp = 44.dp) {
    val ch = name?.trim()?.firstOrNull { it.isLetter() }
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(ClOrange.copy(alpha = 0.16f)),
        contentAlignment = Alignment.Center,
    ) {
        if (ch != null) {
            Text(
                ch.uppercase(),
                color = ClOrange,
                fontSize = (size.value * 0.4f).sp,
                fontWeight = FontWeight.Medium,
            )
        } else {
            Ico(R.drawable.ic_user, size * 0.5f, ClOrange)
        }
    }
}

@Composable
fun Logo(size: TextUnit = 28.sp) {
    Text(
        buildAnnotatedString {
            withStyle(SpanStyle(color = ClOrange)) { append("Cl") }
            append("Call")
        },
        fontSize = size,
        fontWeight = FontWeight.ExtraBold,
        color = MaterialTheme.colorScheme.onBackground,
    )
}
