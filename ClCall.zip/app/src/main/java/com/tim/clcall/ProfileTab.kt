package com.tim.clcall

import android.content.Context
import android.provider.CallLog
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*

class ProfileState(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("cl_profile", Context.MODE_PRIVATE)

    var name by mutableStateOf(prefs.getString("name", "") ?: "")
        private set

    fun update(value: String) {
        name = value
        prefs.edit().putString("name", value).apply()
    }
}

@Composable
fun ProfileTab(
    profile: ProfileState,
    calls: List<CallEntry>,
    contacts: List<ContactEntry>,
    corePerms: Boolean,
    isDefault: Boolean,
    onAskPerms: () -> Unit,
    onSetDefault: () -> Unit,
) {
    val c = MaterialTheme.colorScheme
    val missed = calls.count { it.type == CallLog.Calls.MISSED_TYPE }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 8.dp)
    ) {
        Text("Профиль", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = c.onBackground)
        Spacer(Modifier.height(24.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(profile.name.ifBlank { "C" }, 72.dp)
            Spacer(Modifier.width(16.dp))
            OutlinedTextField(
                value = profile.name,
                onValueChange = { profile.update(it) },
                label = { Text("Ваше имя") },
                singleLine = true,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = c.primary,
                    cursorColor = c.primary,
                    focusedLabelColor = c.primary,
                    unfocusedBorderColor = c.outline,
                ),
            )
        }

        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Звонков", calls.size, Modifier.weight(1f))
            StatCard("Пропущенных", missed, Modifier.weight(1f))
            StatCard("Контактов", contacts.size, Modifier.weight(1f))
        }

        Spacer(Modifier.height(24.dp))
        InfoCard(
            title = "Приложение для звонков",
            text = if (isDefault) "ClCall — основное приложение для звонков. Входящие и разговоры открываются на экранах ClCall."
            else "Сейчас звонки обрабатывает системное приложение. Назначьте ClCall основным — и появятся свои экраны входящего звонка и разговора.",
            action = if (isDefault) null else "Сделать основным",
            onAction = onSetDefault,
        )
        Spacer(Modifier.height(12.dp))
        InfoCard(
            title = "Доступ",
            text = if (corePerms) "Журнал звонков, контакты и телефон разрешены."
            else "Нужен доступ к журналу звонков, контактам и телефону, иначе список и поиск будут пустыми.",
            action = if (corePerms) null else "Разрешить",
            onAction = onAskPerms,
        )
        Spacer(Modifier.height(12.dp))
        InfoCard(
            title = "ClCall 1.0",
            text = "Все данные берутся из журнала звонков и контактов телефона, ClCall ничего не отправляет в интернет.",
            action = null,
            onAction = {},
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun InfoCard(title: String, text: String, action: String?, onAction: () -> Unit) {
    val c = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(c.surfaceVariant)
            .border(1.dp, c.outline, shape)
            .padding(18.dp)
    ) {
        Text(title, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = c.onBackground)
        Spacer(Modifier.height(6.dp))
        Text(text, fontSize = 14.sp, color = c.onSurfaceVariant)
        if (action != null) {
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = {
                    Sounds.click(ctx)
                    onAction()
                },
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = ClBrick, contentColor = Color.White),
            ) { Text(action) }
        }
    }
}

@Composable
private fun StatCard(label: String, value: Int, modifier: Modifier) {
    val c = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier
            .clip(shape)
            .background(c.surface)
            .border(1.dp, c.outline, shape)
            .padding(14.dp)
    ) {
        Text(value.toString(), fontSize = 26.sp, fontWeight = FontWeight.Bold, color = c.onBackground)
        Spacer(Modifier.height(4.dp))
        Text(label, fontSize = 12.sp, color = c.onSurfaceVariant, maxLines = 1)
    }
}
