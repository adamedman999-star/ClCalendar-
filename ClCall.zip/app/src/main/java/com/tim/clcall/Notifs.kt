package com.tim.clcall

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.telecom.Call
import androidx.core.app.NotificationCompat
import androidx.core.app.Person

object Notifs {
    const val CH_CALLS = "calls"
    const val CH_REMIND = "remind"
    const val ID = 1001
    private const val FLAGS = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

    fun channels(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            val calls = NotificationChannel(CH_CALLS, "Звонки", NotificationManager.IMPORTANCE_HIGH)
            calls.setSound(null, null)
            calls.enableVibration(false)
            nm.createNotificationChannel(calls)
            nm.createNotificationChannel(
                NotificationChannel(CH_REMIND, "Напоминания о звонках", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
    }

    private fun incallIntent(ctx: Context): Intent =
        Intent(ctx, InCallActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)

    fun update(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val call = CallHolder.primary
        if (call == null) {
            nm.cancel(ID)
            return
        }
        channels(ctx)
        val info = CallHolder.info(call)
        val name = info?.name
            ?: info?.number?.takeIf { it.isNotBlank() }
            ?: "Неизвестный номер"
        val person = Person.Builder().setName(name).setImportant(true).build()
        val open = PendingIntent.getActivity(ctx, 1, incallIntent(ctx), FLAGS)
        val b = NotificationCompat.Builder(ctx, CH_CALLS)
            .setSmallIcon(R.drawable.ic_phone)
            .setColor(0xFFF28C28.toInt())
            .setContentIntent(open)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setOngoing(true)
            .setOnlyAlertOnce(true)

        if (CallHolder.stateOf(call) == Call.STATE_RINGING) {
            val answer = PendingIntent.getActivity(
                ctx, 2, incallIntent(ctx).putExtra(InCallActivity.EXTRA_ANSWER, true), FLAGS
            )
            val decline = PendingIntent.getBroadcast(
                ctx, 3, Intent(ctx, CallActionReceiver::class.java).setAction(CallActionReceiver.DECLINE), FLAGS
            )
            b.setStyle(NotificationCompat.CallStyle.forIncomingCall(person, decline, answer))
                .setFullScreenIntent(open, true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
        } else {
            val hang = PendingIntent.getBroadcast(
                ctx, 4, Intent(ctx, CallActionReceiver::class.java).setAction(CallActionReceiver.HANGUP), FLAGS
            )
            b.setStyle(NotificationCompat.CallStyle.forOngoingCall(person, hang))
        }
        nm.notify(ID, b.build())
    }
}
