package com.tim.clcalendar

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

/** remindMin: минуты от полуночи, -1 — без напоминания */
data class Note(val id: Long, val epochDay: Long, val text: String, val remindMin: Int = -1)

class NotesState(context: Context) {
    private val ctx = context.applicationContext
    private val prefs = ctx.getSharedPreferences("cl_calendar", Context.MODE_PRIVATE)
    val notes = mutableStateListOf<Note>()

    init {
        try {
            val arr = JSONArray(prefs.getString("notes", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                notes.add(
                    Note(o.getLong("id"), o.getLong("day"), o.getString("text"), o.optInt("rem", -1))
                )
            }
        } catch (_: Exception) {
        }
    }

    fun add(day: LocalDate, text: String, remindMin: Int) {
        val note = Note(System.currentTimeMillis(), day.toEpochDay(), text.trim(), remindMin)
        notes.add(note)
        save()
        Reminders.schedule(ctx, note)
    }

    fun remove(note: Note) {
        notes.remove(note)
        save()
        Reminders.cancel(ctx, note)
    }

    private fun save() {
        val arr = JSONArray()
        notes.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("day", it.epochDay)
                    .put("text", it.text)
                    .put("rem", it.remindMin)
            )
        }
        prefs.edit().putString("notes", arr.toString()).apply()
    }
}
