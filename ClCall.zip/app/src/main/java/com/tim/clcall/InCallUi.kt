package com.tim.clcall

import android.content.Intent
import android.net.Uri
import android.telecom.Call
import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private fun mmss(s: Long): String =
    if (s >= 3600) "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
    else "%02d:%02d".format(s / 60, s % 60)

@Composable
fun InCallScreen(onFinish: () -> Unit) {
    val c = MaterialTheme.colorScheme
    val call = CallHolder.primary
    var seen by remember { mutableStateOf(false) }

    LaunchedEffect(call) {
        if (call != null) {
            seen = true
        } else {
            delay(if (seen) 600L else 4000L)
            if (CallHolder.primary == null) onFinish()
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(c.background)
    ) {
        if (call == null) {
            Text(
                "Соединение…",
                modifier = Modifier.align(Alignment.Center),
                color = c.onSurfaceVariant,
                fontSize = 16.sp,
            )
        } else {
            val state = CallHolder.stateOf(call)
            if (state == Call.STATE_RINGING) IncomingUi(call) else ActiveUi(call, state)
        }
    }
}

private fun titleOf(info: CallInfo?): String =
    info?.name ?: pretty(info?.number ?: "").ifBlank { "Неизвестный номер" }

@Composable
private fun IncomingUi(call: Call) {
    val ctx = LocalContext.current
    val c = MaterialTheme.colorScheme
    val info = CallHolder.info(call)
    val name = titleOf(info)
    val sub = listOfNotNull(info?.label, info?.carrier).joinToString(" · ")
        .ifBlank { "Входящий звонок" }
    val number = info?.number ?: ""

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(24.dp))
        Text("Входящий звонок", fontSize = 13.sp, color = c.onSurfaceVariant)
        Spacer(Modifier.height(40.dp))
        Avatar(info?.name, 112.dp)
        Spacer(Modifier.height(20.dp))
        Text(
            name,
            fontSize = 30.sp,
            fontWeight = FontWeight.Medium,
            color = c.onBackground,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.height(6.dp))
        Text(sub, fontSize = 15.sp, color = c.onSurfaceVariant)
        Spacer(Modifier.weight(1f))

        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 28.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            QuickAction(R.drawable.ic_clock, "Напомнить") {
                if (number.isBlank()) {
                    Toast.makeText(ctx, "У номера нет данных для напоминания", Toast.LENGTH_SHORT).show()
                } else {
                    Remind.schedule(ctx, info?.name ?: pretty(number), number)
                    Toast.makeText(ctx, "Напомню через 15 минут", Toast.LENGTH_SHORT).show()
                    CallHolder.reject(call)
                }
            }
            QuickAction(R.drawable.ic_message, "Сообщение") {
                CallHolder.reject(call)
                if (number.isNotBlank()) {
                    try {
                        ctx.startActivity(
                            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + number))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (_: Exception) {
                    }
                }
            }
        }
        Spacer(Modifier.height(32.dp))

        Row(
            Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(ClBrick)
                    .clClick { CallHolder.reject(call) },
                contentAlignment = Alignment.Center,
            ) {
                Ico(R.drawable.ic_phone, 28.dp, Color.White, Modifier.rotate(135f))
            }
            SlideToAnswer(Modifier.weight(1f)) { CallHolder.answer(call) }
        }
    }
}

@Composable
private fun QuickAction(res: Int, label: String, onClick: () -> Unit) {
    val c = MaterialTheme.colorScheme
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(c.surfaceVariant)
                .clClick(onClick),
            contentAlignment = Alignment.Center,
        ) {
            Ico(res, 24.dp, c.onSurface)
        }
        Spacer(Modifier.height(6.dp))
        Text(label, fontSize = 12.sp, color = c.onSurfaceVariant)
    }
}

@Composable
private fun SlideToAnswer(modifier: Modifier, onAnswer: () -> Unit) {
    val c = MaterialTheme.colorScheme
    val density = LocalDensity.current
    var offset by remember { mutableFloatStateOf(0f) }
    val shape = RoundedCornerShape(32.dp)

    BoxWithConstraints(
        modifier
            .height(64.dp)
            .clip(shape)
            .background(c.surface)
            .border(1.dp, c.outline, shape)
    ) {
        val knobPx = with(density) { 56.dp.toPx() }
        val padPx = with(density) { 8.dp.toPx() }
        val maxPx = (with(density) { maxWidth.toPx() } - knobPx - padPx).coerceAtLeast(1f)

        Row(
            Modifier
                .fillMaxSize()
                .padding(start = 68.dp, end = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "Проведите, чтобы ответить",
                modifier = Modifier.weight(1f),
                fontSize = 13.sp,
                color = c.onSurfaceVariant,
                maxLines = 1,
            )
            Ico(R.drawable.ic_chevrons, 20.dp, ClOrange)
        }
        Box(
            Modifier
                .padding(4.dp)
                .offset { IntOffset(offset.roundToInt(), 0) }
                .size(56.dp)
                .clip(CircleShape)
                .background(ClGreen)
                .pointerInput(maxPx) {
                    detectHorizontalDragGestures(
                        onDragEnd = {
                            if (offset > maxPx * 0.8f) onAnswer() else offset = 0f
                        },
                        onDragCancel = { offset = 0f },
                        onHorizontalDrag = { change, dx ->
                            change.consume()
                            offset = (offset + dx).coerceIn(0f, maxPx)
                        },
                    )
                },
            contentAlignment = Alignment.Center,
        ) {
            Ico(R.drawable.ic_phone, 26.dp, Color.White)
        }
    }
}

@Composable
private fun ActiveUi(call: Call, state: Int) {
    val ctx = LocalContext.current
    val c = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    val info = CallHolder.info(call)
    var pad by remember { mutableStateOf(false) }
    var typed by remember { mutableStateOf("") }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(500)
        }
    }

    val connect = call.details.connectTimeMillis
    val status = when (state) {
        Call.STATE_ACTIVE -> if (connect > 0) mmss(((now - connect) / 1000).coerceAtLeast(0)) else "00:00"
        Call.STATE_HOLDING -> "Удержание"
        Call.STATE_DISCONNECTING, Call.STATE_DISCONNECTED -> "Завершение…"
        else -> "Вызов…"
    }
    val held = state == Call.STATE_HOLDING
    val sub = listOfNotNull(info?.label, info?.carrier).joinToString(" · ")

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(24.dp))
        Text(
            status,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium,
            color = if (state == Call.STATE_ACTIVE) ClGreen else c.onSurfaceVariant,
        )
        Spacer(Modifier.height(28.dp))
        Avatar(info?.name, 96.dp)
        Spacer(Modifier.height(18.dp))
        Text(
            titleOf(info),
            fontSize = 30.sp,
            fontWeight = FontWeight.Medium,
            color = c.onBackground,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        if (sub.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(sub, fontSize = 15.sp, color = c.onSurfaceVariant)
        }
        Spacer(Modifier.weight(1f))

        if (pad) {
            Text(
                typed.ifEmpty { " " },
                fontSize = 24.sp,
                color = c.onBackground,
                maxLines = 1,
            )
            Spacer(Modifier.height(12.dp))
            DtmfPad { ch ->
                typed += ch
                call.playDtmfTone(ch)
                scope.launch {
                    delay(150)
                    call.stopDtmfTone()
                }
            }
            TextButton(onClick = {
                Sounds.click(ctx)
                pad = false
            }) { Text("Скрыть", color = ClOrange) }
        } else {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(22.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    RoundCtl(R.drawable.ic_volume, "Динамик", CallHolder.speaker) {
                        CallHolder.setSpeaker(!CallHolder.speaker)
                    }
                    RoundCtl(R.drawable.ic_dialpad, "Клавиатура", false) { pad = true }
                    RoundCtl(R.drawable.ic_mic_off, "Микрофон", CallHolder.muted) {
                        CallHolder.setMuted(!CallHolder.muted)
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    RoundCtl(R.drawable.ic_record, "Запись", false) {
                        Toast.makeText(
                            ctx,
                            "Android не разрешает сторонним приложениям записывать разговоры",
                            Toast.LENGTH_LONG,
                        ).show()
                    }
                    RoundCtl(R.drawable.ic_add, "Добавить", false) {
                        ctx.startActivity(
                            Intent(Intent.ACTION_DIAL)
                                .setClass(ctx, MainActivity::class.java)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                    RoundCtl(R.drawable.ic_pause, "Удержание", held) { CallHolder.toggleHold(call) }
                }
            }
        }
        Spacer(Modifier.height(28.dp))
        Box(
            Modifier
                .size(68.dp)
                .clip(CircleShape)
                .background(ClBrick)
                .clClick { CallHolder.hangup(call) },
            contentAlignment = Alignment.Center,
        ) {
            Ico(R.drawable.ic_phone, 30.dp, Color.White, Modifier.rotate(135f))
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun RoundCtl(res: Int, label: String, active: Boolean, onClick: () -> Unit) {
    val c = MaterialTheme.colorScheme
    Column(Modifier.width(88.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(60.dp)
                .clip(CircleShape)
                .background(if (active) ClOrange else c.surfaceVariant)
                .clClick(onClick),
            contentAlignment = Alignment.Center,
        ) {
            Ico(res, 26.dp, if (active) Color.White else c.onSurface)
        }
        Spacer(Modifier.height(6.dp))
        Text(label, fontSize = 12.sp, color = c.onSurfaceVariant)
    }
}

@Composable
private fun DtmfPad(onKey: (Char) -> Unit) {
    val ctx = LocalContext.current
    val c = MaterialTheme.colorScheme
    val rows = listOf("123", "456", "789", "*0#")
    Column(
        Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        rows.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                row.forEach { ch ->
                    Box(
                        Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(c.surfaceVariant)
                            .pointerInput(ch) {
                                detectTapGestures(onPress = {
                                    Sounds.key(ctx, ch)
                                    onKey(ch)
                                })
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(ch.toString(), fontSize = 26.sp, color = c.onSurface)
                    }
                }
            }
        }
    }
}
