package com.tim.clcall

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.telephony.PhoneNumberUtils
import android.telephony.SubscriptionManager
import androidx.core.content.ContextCompat

data class CallEntry(
    val id: Long,
    val number: String,
    val name: String?,
    val type: Int,
    val date: Long,
    val label: String?,
    val carrier: String?,
)

data class ContactEntry(val name: String, val number: String, val label: String?)

data class Who(val name: String?, val label: String?)

object Perms {
    val list: Array<String> = buildList {
        add(Manifest.permission.CALL_PHONE)
        add(Manifest.permission.READ_CALL_LOG)
        add(Manifest.permission.READ_CONTACTS)
        add(Manifest.permission.READ_PHONE_STATE)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }.toTypedArray()

    fun has(ctx: Context, p: String): Boolean =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    fun core(ctx: Context): Boolean =
        has(ctx, Manifest.permission.READ_CALL_LOG) &&
            has(ctx, Manifest.permission.READ_CONTACTS) &&
            has(ctx, Manifest.permission.CALL_PHONE)

    fun all(ctx: Context): Boolean = list.all { has(ctx, it) }
}

object Carriers {
    fun map(ctx: Context): Map<String, String> {
        val out = HashMap<String, String>()
        try {
            if (!Perms.has(ctx, Manifest.permission.READ_PHONE_STATE)) return out
            val sm = ctx.getSystemService(SubscriptionManager::class.java)
            sm.activeSubscriptionInfoList?.forEach { s ->
                val n = s.carrierName?.toString()
                if (!n.isNullOrBlank()) {
                    out[s.subscriptionId.toString()] = n
                    val icc = s.iccId
                    if (!icc.isNullOrBlank()) out[icc] = n
                }
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun find(map: Map<String, String>, acc: String?): String? {
        if (map.isEmpty()) return null
        if (acc != null) {
            map[acc]?.let { return it }
            map.entries
                .firstOrNull { acc.startsWith(it.key) || it.key.startsWith(acc) }
                ?.let { return it.value }
        }
        val uniq = map.values.toSet()
        return if (uniq.size == 1) uniq.first() else null
    }

    fun forAccount(ctx: Context, acc: String?): String? = find(map(ctx), acc)
}

fun pretty(n: String): String {
    if (n.isEmpty() || n.any { it == '*' || it == '#' }) return n
    return try {
        PhoneNumberUtils.formatNumber(n, "RU") ?: n
    } catch (_: Exception) {
        n
    }
}

fun digitsOf(s: String): String = s.filter { it.isDigit() }

object Repo {
    fun loadCalls(ctx: Context): List<CallEntry> {
        if (!Perms.has(ctx, Manifest.permission.READ_CALL_LOG)) return emptyList()
        val carriers = Carriers.map(ctx)
        val out = ArrayList<CallEntry>()
        try {
            val cols = arrayOf(
                CallLog.Calls._ID,
                CallLog.Calls.NUMBER,
                CallLog.Calls.CACHED_NAME,
                CallLog.Calls.TYPE,
                CallLog.Calls.DATE,
                CallLog.Calls.CACHED_NUMBER_TYPE,
                CallLog.Calls.CACHED_NUMBER_LABEL,
                CallLog.Calls.PHONE_ACCOUNT_ID,
            )
            ctx.contentResolver.query(
                CallLog.Calls.CONTENT_URI, cols, null, null, CallLog.Calls.DATE + " DESC"
            )?.use { c ->
                while (c.moveToNext() && out.size < 300) {
                    val typeCode = c.getInt(5)
                    val label = if (typeCode != 0) {
                        ContactsContract.CommonDataKinds.Phone
                            .getTypeLabel(ctx.resources, typeCode, c.getString(6)).toString()
                    } else null
                    out.add(
                        CallEntry(
                            id = c.getLong(0),
                            number = c.getString(1) ?: "",
                            name = c.getString(2)?.takeIf { it.isNotBlank() },
                            type = c.getInt(3),
                            date = c.getLong(4),
                            label = label,
                            carrier = Carriers.find(carriers, c.getString(7)),
                        )
                    )
                }
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun loadContacts(ctx: Context): List<ContactEntry> {
        if (!Perms.has(ctx, Manifest.permission.READ_CONTACTS)) return emptyList()
        val out = ArrayList<ContactEntry>()
        val seen = HashSet<String>()
        try {
            val cols = arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER, Phone.TYPE, Phone.LABEL)
            ctx.contentResolver.query(
                Phone.CONTENT_URI, cols, null, null, Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC"
            )?.use { c ->
                while (c.moveToNext() && out.size < 3000) {
                    val name = c.getString(0) ?: continue
                    val num = c.getString(1) ?: continue
                    val key = name + "|" + digitsOf(num)
                    if (!seen.add(key)) continue
                    val t = c.getInt(2)
                    val label = if (t != 0) {
                        Phone.getTypeLabel(ctx.resources, t, c.getString(3)).toString()
                    } else null
                    out.add(ContactEntry(name, num, label))
                }
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun lookup(ctx: Context, number: String): Who {
        if (number.isBlank() || !Perms.has(ctx, Manifest.permission.READ_CONTACTS)) {
            return Who(null, null)
        }
        try {
            val uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)
            )
            val cols = arrayOf(
                ContactsContract.PhoneLookup.DISPLAY_NAME,
                ContactsContract.PhoneLookup.TYPE,
                ContactsContract.PhoneLookup.LABEL,
            )
            ctx.contentResolver.query(uri, cols, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val t = c.getInt(1)
                    val label = if (t != 0) {
                        ContactsContract.CommonDataKinds.Phone
                            .getTypeLabel(ctx.resources, t, c.getString(2)).toString()
                    } else null
                    return Who(c.getString(0), label)
                }
            }
        } catch (_: Exception) {
        }
        return Who(null, null)
    }
}
