package com.tim.clcalendar

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

data class Task(val id: Long, val title: String, val done: Boolean)

class TasksState(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("cl_tasks", Context.MODE_PRIVATE)
    val tasks = mutableStateListOf<Task>()

    init {
        try {
            val arr = JSONArray(prefs.getString("tasks", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                tasks.add(Task(o.getLong("id"), o.getString("title"), o.optBoolean("done", false)))
            }
        } catch (_: Exception) {
        }
    }

    fun add(title: String) {
        tasks.add(Task(System.currentTimeMillis(), title.trim(), false))
        save()
    }

    fun toggle(task: Task) {
        val i = tasks.indexOf(task)
        if (i >= 0) {
            tasks[i] = task.copy(done = !task.done)
            save()
        }
    }

    fun remove(task: Task) {
        tasks.remove(task)
        save()
    }

    fun clearDone() {
        tasks.removeAll { it.done }
        save()
    }

    private fun save() {
        val arr = JSONArray()
        tasks.forEach {
            arr.put(JSONObject().put("id", it.id).put("title", it.title).put("done", it.done))
        }
        prefs.edit().putString("tasks", arr.toString()).apply()
    }
}

class ProfileState(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("cl_profile", Context.MODE_PRIVATE)

    var name by mutableStateOf(prefs.getString("name", "") ?: "")
        private set

    fun update(value: String) {
        name = value
        prefs.edit().putString("name", value).apply()
    }
}
