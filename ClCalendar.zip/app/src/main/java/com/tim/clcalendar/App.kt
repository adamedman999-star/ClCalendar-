package com.tim.clcalendar

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*

enum class AppTab(val label: String, val icon: Int) {
    CALENDAR("Календарь", R.drawable.ic_nav_calendar),
    TASKS("Задачи", R.drawable.ic_nav_tasks),
    PROFILE("Профиль", R.drawable.ic_nav_profile),
}

@Composable
fun ClApp(notes: NotesState, tasks: TasksState, profile: ProfileState) {
    var tab by remember { mutableStateOf(AppTab.CALENDAR) }
    val c = MaterialTheme.colorScheme

    Scaffold(
        containerColor = c.background,
        contentWindowInsets = WindowInsets(0.dp, 0.dp, 0.dp, 0.dp),
        bottomBar = { NavBar(tab) { tab = it } },
    ) { padding ->
        Box(
            Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            when (tab) {
                AppTab.CALENDAR -> CalendarTab(notes)
                AppTab.TASKS -> TasksTab(tasks)
                AppTab.PROFILE -> ProfileTab(profile, notes, tasks)
            }
        }
    }
}

@Composable
private fun NavBar(current: AppTab, onPick: (AppTab) -> Unit) {
    val c = MaterialTheme.colorScheme
    Column(Modifier.background(c.surface)) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(c.outline)
        )
        Row(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .height(64.dp)
        ) {
            AppTab.values().forEach { t ->
                val sel = t == current
                val col = if (sel) c.primary else c.onSurfaceVariant
                Column(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable { onPick(t) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Image(
                        painter = painterResource(t.icon),
                        contentDescription = null,
                        modifier = Modifier.size(24.dp),
                        colorFilter = ColorFilter.tint(col),
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        t.label,
                        fontSize = 11.sp,
                        color = col,
                        fontWeight = if (sel) FontWeight.Medium else FontWeight.Normal,
                    )
                }
            }
        }
    }
}
