package com.tim.clcalendar

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

data class Note(val id: Long, val epochDay: Long, val text: String)

class NotesState(context: Context) {
    private val prefs = context.getSharedPreferences("cl_calendar", Context.MODE_PRIVATE)
    val notes = mutableStateListOf<Note>()

    init {
        try {
            val arr = JSONArray(prefs.getString("notes", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                notes.add(Note(o.getLong("id"), o.getLong("day"), o.getString("text")))
            }
        } catch (_: Exception) {
        }
    }

    fun add(day: LocalDate, text: String) {
        notes.add(Note(System.currentTimeMillis(), day.toEpochDay(), text.trim()))
        save()
    }

    fun remove(note: Note) {
        notes.remove(note)
        save()
    }

    private fun save() {
        val arr = JSONArray()
        notes.forEach {
            arr.put(JSONObject().put("id", it.id).put("day", it.epochDay).put("text", it.text))
        }
        prefs.edit().putString("notes", arr.toString()).apply()
    }
}
