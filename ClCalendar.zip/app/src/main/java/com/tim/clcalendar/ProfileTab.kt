package com.tim.clcalendar

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import java.time.LocalDate

@Composable
fun ProfileTab(profile: ProfileState, notes: NotesState, tasks: TasksState) {
    val c = MaterialTheme.colorScheme
    val todayDay = remember { LocalDate.now().toEpochDay() }
    val total = notes.notes.size
    val upcoming = notes.notes.count { it.remindMin >= 0 && it.epochDay >= todayDay }
    val done = tasks.tasks.count { it.done }
    val initial = profile.name.trim().firstOrNull()?.uppercase() ?: "C"

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 8.dp)
    ) {
        Text("Профиль", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = c.onBackground)
        Spacer(Modifier.height(24.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(ClOrange),
                contentAlignment = Alignment.Center,
            ) {
                Text(initial, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(16.dp))
            OutlinedTextField(
                value = profile.name,
                onValueChange = { profile.update(it) },
                label = { Text("Ваше имя") },
                singleLine = true,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = c.primary,
                    cursorColor = c.primary,
                    focusedLabelColor = c.primary,
                    unfocusedBorderColor = c.outline,
                ),
            )
        }

        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Заметок", total, Modifier.weight(1f))
            StatCard("Напоминаний впереди", upcoming, Modifier.weight(1f))
            StatCard("Задач сделано", done, Modifier.weight(1f))
        }

        Spacer(Modifier.height(24.dp))
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(c.surfaceVariant)
                .border(1.dp, c.outline, RoundedCornerShape(20.dp))
                .padding(18.dp)
        ) {
            Text("ClCalendar 1.0", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = c.onBackground)
            Spacer(Modifier.height(6.dp))
            Text(
                "Все заметки и задачи хранятся только на этом телефоне. " +
                    "Светлая и тёмная тема подстраиваются под настройки системы.",
                fontSize = 14.sp,
                color = c.onSurfaceVariant,
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun StatCard(label: String, value: Int, modifier: Modifier) {
    val c = MaterialTheme.colorScheme
    Column(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(c.surface)
            .border(1.dp, c.outline, RoundedCornerShape(20.dp))
            .padding(14.dp)
    ) {
        Text(value.toString(), fontSize = 26.sp, fontWeight = FontWeight.Bold, color = c.onBackground)
        Spacer(Modifier.height(4.dp))
        Text(label, fontSize = 12.sp, color = c.onSurfaceVariant, maxLines = 2)
    }
}
