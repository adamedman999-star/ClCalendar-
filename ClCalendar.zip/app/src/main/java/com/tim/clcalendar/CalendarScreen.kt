package com.tim.clcalendar

import android.Manifest
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

private val RU: Locale = Locale.forLanguageTag("ru")
private const val PAGES = 2400
private const val START = 1200
private val WEEKDAYS = listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")
private val MONTH_ART = listOf(
    R.drawable.month_01, R.drawable.month_02, R.drawable.month_03, R.drawable.month_04,
    R.drawable.month_05, R.drawable.month_06, R.drawable.month_07, R.drawable.month_08,
    R.drawable.month_09, R.drawable.month_10, R.drawable.month_11, R.drawable.month_12,
)

private fun fmt(min: Int) = "%02d:%02d".format(min / 60, min % 60)

/** Карточка в общем стиле: скругление, тонкая граница, мягкий градиент. */
@Composable
private fun ClCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit,
) {
    val c = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(24.dp)
    Box(
        modifier
            .clip(shape)
            .background(Brush.verticalGradient(listOf(c.surface, c.surfaceVariant)))
            .border(1.dp, c.outline, shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
    ) { content() }
}

@Composable
fun CalendarScreen(state: NotesState) {
    val today = remember { LocalDate.now() }
    val base = remember { YearMonth.from(today) }
    val pager = rememberPagerState(initialPage = START, pageCount = { PAGES })
    val scope = rememberCoroutineScope()
    var selected by remember { mutableStateOf(today) }
    var sheetOpen by remember { mutableStateOf(false) }
    val current = base.plusMonths((pager.currentPage - START).toLong())
    val title = current.month.getDisplayName(TextStyle.FULL_STANDALONE, RU)
        .replaceFirstChar { it.uppercase() } + " " + current.year
    val c = MaterialTheme.colorScheme

    LaunchedEffect(pager.settledPage) {
        val m = base.plusMonths((pager.settledPage - START).toLong())
        if (YearMonth.from(selected) != m) selected = if (m == base) today else m.atDay(1)
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(c.background)
            .drawBehind {
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(ClOrange.copy(alpha = 0.20f), Color.Transparent),
                        center = Offset(size.width, 0f),
                        radius = size.width * 0.95f,
                    )
                )
            }
    ) {
        Scaffold(
            containerColor = Color.Transparent,
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { sheetOpen = true },
                    containerColor = c.primary,
                    contentColor = Color.White,
                    shape = CircleShape,
                    modifier = Modifier.size(60.dp),
                ) {
                    Text("+", fontSize = 30.sp)
                }
            },
        ) { padding ->
            Column(
                Modifier
                    .padding(padding)
                    .padding(start = 16.dp, end = 16.dp, bottom = 16.dp)
                    .fillMaxSize()
            ) {
                // Верхняя панель
                Row(
                    Modifier
                        .statusBarsPadding()
                        .padding(vertical = 12.dp, horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    androidx.compose.foundation.Image(
                        painter = painterResource(R.drawable.ic_header),
                        contentDescription = null,
                        modifier = Modifier.size(32.dp),
                    )
                    Spacer(Modifier.width(14.dp))
                    Text(
                        "ClCalendar",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Medium,
                        color = c.onBackground,
                    )
                }

                // Месяц и стрелки
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(c.surface)
                            .border(1.dp, c.outline, RoundedCornerShape(20.dp))
                            .clickable {
                                selected = today
                                scope.launch { pager.animateScrollToPage(START) }
                            }
                            .padding(horizontal = 18.dp, vertical = 10.dp)
                    ) {
                        Text(title, fontSize = 18.sp, color = c.onSurface)
                    }
                    Row {
                        ArrowButton("‹") {
                            scope.launch { pager.animateScrollToPage(pager.currentPage - 1) }
                        }
                        ArrowButton("›") {
                            scope.launch { pager.animateScrollToPage(pager.currentPage + 1) }
                        }
                    }
                }

                // Дни недели
                Row(Modifier.fillMaxWidth()) {
                    WEEKDAYS.forEachIndexed { i, name ->
                        Text(
                            name,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.Center,
                            color = if (i >= 5) WeekendRed else c.onSurfaceVariant,
                            fontSize = 13.sp,
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))

                // Сетка
                ClCard(Modifier.fillMaxWidth()) {
                    HorizontalPager(
                        state = pager,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                    ) { page ->
                        MonthGrid(
                            month = base.plusMonths((page - START).toLong()),
                            today = today,
                            selected = selected,
                            state = state,
                            onDayClick = { selected = it },
                        )
                    }
                }

                // Иллюстрация месяца
                BoxWithConstraints(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    val d = minOf(maxHeight, maxWidth, 220.dp)
                    if (d >= 72.dp) {
                        Crossfade(targetState = current.monthValue, label = "monthArt") { m ->
                            Image(
                                painter = painterResource(MONTH_ART[m - 1]),
                                contentDescription = null,
                                modifier = Modifier
                                    .size(d)
                                    .clip(CircleShape)
                                    .border(1.dp, c.outline, CircleShape),
                            )
                        }
                    }
                }

                // События выбранного дня (справа остаётся место под кнопку «+»)
                EventsCard(
                    day = selected,
                    state = state,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(end = 76.dp),
                    onOpen = { sheetOpen = true },
                )
            }
        }
    }

    if (sheetOpen) {
        NoteSheet(day = selected, state = state, onDismiss = { sheetOpen = false })
    }
}

@Composable
private fun ArrowButton(label: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, fontSize = 30.sp, color = MaterialTheme.colorScheme.onBackground)
    }
}

@Composable
private fun EventsCard(day: LocalDate, state: NotesState, modifier: Modifier, onOpen: () -> Unit) {
    val c = MaterialTheme.colorScheme
    val notes = state.notes.filter { it.epochDay == day.toEpochDay() }
    val holiday = Holidays.name(day)
    val title = "События на " + day.format(DateTimeFormatter.ofPattern("d MMMM", RU))

    ClCard(modifier, onClick = onOpen) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    title,
                    modifier = Modifier.weight(1f),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    color = c.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text("›", fontSize = 22.sp, color = c.primary)
            }
            if (holiday != null) {
                Text(holiday, fontSize = 13.sp, color = WeekendRed)
            }
            Spacer(Modifier.height(8.dp))
            if (notes.isEmpty() && holiday == null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(c.surfaceVariant)
                            .border(1.dp, c.outline, CircleShape),
                        contentAlignment = Alignment.Center,
                    ) { Text("✓", color = c.primary, fontSize = 16.sp) }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("Нет событий", color = c.onSurface, fontSize = 15.sp)
                        Text("Отличный день!", color = c.onSurfaceVariant, fontSize = 13.sp)
                    }
                }
            } else {
                notes.take(2).forEach { n ->
                    Row(
                        Modifier.padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            n.text,
                            modifier = Modifier.weight(1f, fill = false),
                            color = c.onSurface,
                            fontSize = 15.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        if (n.remindMin >= 0) {
                            Text(
                                "  🔔 " + fmt(n.remindMin),
                                color = c.primary,
                                fontSize = 12.sp,
                            )
                        }
                    }
                }
                if (notes.size > 2) {
                    Text("и ещё ${notes.size - 2}", color = c.onSurfaceVariant, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
private fun MonthGrid(
    month: YearMonth,
    today: LocalDate,
    selected: LocalDate,
    state: NotesState,
    onDayClick: (LocalDate) -> Unit,
) {
    val offset = month.atDay(1).dayOfWeek.value - 1
    val length = month.lengthOfMonth()
    val daysWithNotes = state.notes.map { it.epochDay }.toSet()

    Column(Modifier.fillMaxWidth()) {
        for (row in 0 until 6) {
            Row(Modifier.fillMaxWidth()) {
                for (col in 0 until 7) {
                    val dayNum = row * 7 + col - offset + 1
                    val date = if (dayNum in 1..length) month.atDay(dayNum) else null
                    DayCell(
                        modifier = Modifier
                            .weight(1f)
                            .aspectRatio(1.1f),
                        date = date,
                        today = today,
                        selected = selected,
                        hasNotes = date != null && date.toEpochDay() in daysWithNotes,
                        onClick = onDayClick,
                    )
                }
            }
        }
    }
}

@Composable
private fun DayCell(
    modifier: Modifier,
    date: LocalDate?,
    today: LocalDate,
    selected: LocalDate,
    hasNotes: Boolean,
    onClick: (LocalDate) -> Unit,
) {
    Box(modifier.padding(2.dp), contentAlignment = Alignment.Center) {
        if (date != null) {
            val primary = MaterialTheme.colorScheme.primary
            val isSelected = date == selected
            val isToday = date == today
            val weekend = date.dayOfWeek == DayOfWeek.SATURDAY || date.dayOfWeek == DayOfWeek.SUNDAY
            val holiday = Holidays.name(date) != null
            val shape = RoundedCornerShape(14.dp)
            val textColor = when {
                isSelected -> Color.White
                weekend -> WeekendRed
                holiday -> HolidayRed
                else -> MaterialTheme.colorScheme.onSurface
            }
            Box(
                Modifier
                    .fillMaxSize()
                    .clip(shape)
                    .background(if (isSelected) primary else Color.Transparent)
                    .then(
                        if (isToday && !isSelected) Modifier.border(1.5.dp, primary, shape)
                        else Modifier
                    )
                    .clickable { onClick(date) },
                contentAlignment = Alignment.Center,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        date.dayOfMonth.toString(),
                        fontSize = 17.sp,
                        fontWeight = if (isSelected || isToday) FontWeight.Bold else FontWeight.Normal,
                        color = textColor,
                    )
                    Box(
                        Modifier
                            .padding(top = 2.dp)
                            .size(4.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    !hasNotes -> Color.Transparent
                                    isSelected -> Color.White
                                    else -> primary
                                }
                            )
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NoteSheet(day: LocalDate, state: NotesState, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val c = MaterialTheme.colorScheme
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var text by remember { mutableStateOf("") }
    var remind by remember { mutableStateOf(false) }
    var minutes by remember { mutableStateOf(9 * 60) }
    val dayNotes = state.notes.filter { it.epochDay == day.toEpochDay() }
    val title = day.format(DateTimeFormatter.ofPattern("d MMMM, EEEE", RU))
    val holiday = Holidays.name(day)
    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = c.surface,
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 16.dp)
                .navigationBarsPadding()
                .imePadding()
        ) {
            Text(
                title,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                color = c.onSurface,
            )
            if (holiday != null) {
                Text(holiday, color = WeekendRed, fontSize = 14.sp)
            }
            Spacer(Modifier.height(12.dp))

            if (dayNotes.isEmpty()) {
                Text("Заметок нет", color = c.onSurfaceVariant)
            } else {
                LazyColumn(Modifier.heightIn(max = 260.dp)) {
                    items(dayNotes, key = { it.id }) { note ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(note.text, color = c.onSurface, fontSize = 16.sp)
                                if (note.remindMin >= 0) {
                                    Text(
                                        "🔔 " + fmt(note.remindMin),
                                        color = c.primary,
                                        fontSize = 13.sp,
                                    )
                                }
                            }
                            TextButton(onClick = { state.remove(note) }) {
                                Text("✕", color = c.onSurfaceVariant)
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = { Text("Новая заметка") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    maxLines = 4,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = c.primary,
                        cursorColor = c.primary,
                        unfocusedBorderColor = c.outline,
                    ),
                )
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = {
                        if (text.isNotBlank()) {
                            state.add(day, text, if (remind) minutes else -1)
                            text = ""
                            remind = false
                        }
                    },
                    shape = RoundedCornerShape(16.dp),
                ) { Text("+", fontSize = 20.sp) }
            }

            Row(
                Modifier.padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Switch(
                    checked = remind,
                    onCheckedChange = { on ->
                        remind = on
                        if (on && Build.VERSION.SDK_INT >= 33 &&
                            ContextCompat.checkSelfPermission(
                                ctx, Manifest.permission.POST_NOTIFICATIONS
                            ) != PackageManager.PERMISSION_GRANTED
                        ) {
                            permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    },
                    colors = SwitchDefaults.colors(
                        checkedTrackColor = c.primary,
                        checkedThumbColor = Color.White,
                    ),
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    "Напомнить в этот день",
                    modifier = Modifier.weight(1f),
                    color = c.onSurface,
                )
                if (remind) {
                    TextButton(onClick = {
                        TimePickerDialog(
                            ctx,
                            { _, h, m -> minutes = h * 60 + m },
                            minutes / 60,
                            minutes % 60,
                            true,
                        ).show()
                    }) {
                        Text(fmt(minutes), fontSize = 16.sp)
                    }
                }
            }
        }
    }
}
