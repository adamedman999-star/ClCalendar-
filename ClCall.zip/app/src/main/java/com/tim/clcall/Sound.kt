package com.tim.clcall

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import androidx.compose.foundation.clickable
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext

object Sounds {
    private var pool: SoundPool? = null
    private val ids = HashMap<String, Int>()

    fun init(ctx: Context) {
        if (pool != null) return
        val p = SoundPool.Builder()
            .setMaxStreams(4)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .build()
        val app = ctx.applicationContext
        ids["ui"] = p.load(app, R.raw.ui_click, 1)
        ids["0"] = p.load(app, R.raw.tone_0, 1)
        ids["1"] = p.load(app, R.raw.tone_1, 1)
        ids["2"] = p.load(app, R.raw.tone_2, 1)
        ids["3"] = p.load(app, R.raw.tone_3, 1)
        ids["4"] = p.load(app, R.raw.tone_4, 1)
        ids["5"] = p.load(app, R.raw.tone_5, 1)
        ids["6"] = p.load(app, R.raw.tone_6, 1)
        ids["7"] = p.load(app, R.raw.tone_7, 1)
        ids["8"] = p.load(app, R.raw.tone_8, 1)
        ids["9"] = p.load(app, R.raw.tone_9, 1)
        ids["*"] = p.load(app, R.raw.tone_star, 1)
        ids["#"] = p.load(app, R.raw.tone_hash, 1)
        pool = p
    }

    private fun play(ctx: Context, key: String, vol: Float) {
        init(ctx)
        val id = ids[key] ?: return
        pool?.play(id, vol, vol, 1, 0, 1f)
    }

    fun click(ctx: Context) = play(ctx, "ui", 0.7f)

    fun key(ctx: Context, k: Char) = play(ctx, k.toString(), 1f)
}

@Composable
fun Modifier.clClick(onClick: () -> Unit): Modifier {
    val ctx = LocalContext.current
    return this.clickable {
        Sounds.click(ctx)
        onClick()
    }
}
