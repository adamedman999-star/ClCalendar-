package com.tim.clcalendar

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val text = intent.getStringExtra("text") ?: return
        Reminders.ensureChannel(context)
        Reminders.show(context, intent.getLongExtra("id", 0L), text)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val state = NotesState(context.applicationContext)
        Reminders.rescheduleAll(context.applicationContext, state.notes)
    }
}
