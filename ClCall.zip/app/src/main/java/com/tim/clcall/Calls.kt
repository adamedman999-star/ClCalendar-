package com.tim.clcall

import android.telecom.Call
import android.telecom.InCallService
import android.telecom.VideoProfile
import android.telecom.CallAudioState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class CallInfo(
    val name: String?,
    val number: String,
    val label: String?,
    val carrier: String?,
)

object CallHolder {
    val calls = mutableStateListOf<Call>()
    val states = mutableStateMapOf<Call, Int>()
    val infos = HashMap<Call, CallInfo>()
    var service: InCallService? = null
    var muted by mutableStateOf(false)
    var speaker by mutableStateOf(false)

    val primary: Call?
        get() = calls.firstOrNull { states[it] == Call.STATE_RINGING } ?: calls.lastOrNull()

    @Suppress("DEPRECATION")
    fun stateOf(c: Call): Int = states[c] ?: c.state

    fun info(c: Call): CallInfo? = infos[c]

    fun answer(c: Call) = c.answer(VideoProfile.STATE_AUDIO_ONLY)
    fun reject(c: Call) = c.reject(false, null)
    fun hangup(c: Call) = c.disconnect()

    fun toggleHold(c: Call) {
        if (stateOf(c) == Call.STATE_HOLDING) c.unhold() else c.hold()
    }

    @Suppress("DEPRECATION")
    fun setMuted(v: Boolean) {
        service?.setMuted(v)
    }

    @Suppress("DEPRECATION")
    fun setSpeaker(v: Boolean) {
        service?.setAudioRoute(if (v) CallAudioState.ROUTE_SPEAKER else CallAudioState.ROUTE_EARPIECE)
    }
}
