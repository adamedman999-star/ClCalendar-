package com.tim.clcall

import android.content.ActivityNotFoundException
import android.content.Intent
import android.provider.ContactsContract
import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*

private val KEYS = listOf(
    listOf("1" to "", "2" to "ABC", "3" to "DEF"),
    listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
    listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ"),
    listOf("*" to "", "0" to "+", "#" to ""),
)

@Composable
fun KeypadTab(
    number: String,
    onNumber: (String) -> Unit,
    contacts: List<ContactEntry>,
    onCall: (String) -> Unit,
) {
    val ctx = LocalContext.current
    val c = MaterialTheme.colorScheme
    var menu by remember { mutableStateOf(false) }
    val match = remember(number, contacts) {
        val d = digitsOf(number)
        if (d.length < 3) null
        else contacts.firstOrNull {
            val cd = digitsOf(it.number)
            cd == d || (d.length >= 7 && cd.takeLast(10) == d.takeLast(10))
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(start = 20.dp, end = 16.dp, top = 8.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column {
                Logo()
                Text("Будьте на связи. Позвоните.", fontSize = 13.sp, color = c.onSurfaceVariant)
            }
            Box {
                CircleBtn(R.drawable.ic_dots, c.surfaceVariant, c.onSurface) { menu = true }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Очистить номер") },
                        onClick = {
                            menu = false
                            onNumber("")
                        },
                    )
                }
            }
        }

        Box(
            Modifier
                .fillMaxWidth()
                .height(64.dp)
                .padding(top = 16.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                pretty(number),
                fontSize = when {
                    number.length <= 11 -> 32.sp
                    number.length <= 14 -> 26.sp
                    else -> 22.sp
                },
                fontWeight = FontWeight.Medium,
                color = c.onBackground,
                maxLines = 1,
                softWrap = false,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
            )
        }
        Box(
            Modifier
                .fillMaxWidth()
                .height(32.dp),
            contentAlignment = Alignment.Center,
        ) {
            if (match != null) {
                Text(match.name, fontSize = 15.sp, color = c.onSurfaceVariant)
            } else if (number.length >= 3) {
                Text(
                    "Добавить в контакты",
                    fontSize = 14.sp,
                    color = ClOrange,
                    modifier = Modifier
                        .clClick {
                            try {
                                ctx.startActivity(
                                    Intent(Intent.ACTION_INSERT_OR_EDIT).apply {
                                        type = ContactsContract.Contacts.CONTENT_ITEM_TYPE
                                        putExtra(ContactsContract.Intents.Insert.PHONE, number)
                                    }
                                )
                            } catch (_: ActivityNotFoundException) {
                            }
                        }
                        .padding(8.dp),
                )
            }
        }
        Spacer(Modifier.height(8.dp))

        Column(
            Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            KEYS.forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                    row.forEach { (d, l) ->
                        Key(
                            d,
                            l,
                            onTap = { onNumber(number + d) },
                            onLong = if (d == "0") ({ onNumber(number + "+") }) else null,
                        )
                    }
                }
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(24.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Spacer(Modifier.size(68.dp))
                Box(
                    Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(ClGreen)
                        .clClick {
                            if (number.isBlank()) {
                                Toast.makeText(ctx, "Введите номер", Toast.LENGTH_SHORT).show()
                            } else {
                                onCall(number)
                            }
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Ico(R.drawable.ic_phone, 30.dp, Color.White)
                }
                Box(
                    Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .pointerInput(number) {
                            detectTapGestures(
                                onTap = {
                                    Sounds.click(ctx)
                                    onNumber(number.dropLast(1))
                                },
                                onLongPress = {
                                    Sounds.click(ctx)
                                    onNumber("")
                                },
                            )
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    if (number.isNotEmpty()) Ico(R.drawable.ic_backspace, 26.dp, c.onSurfaceVariant)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun Key(d: String, l: String, onTap: () -> Unit, onLong: (() -> Unit)?) {
    val ctx = LocalContext.current
    val c = MaterialTheme.colorScheme
    Column(
        Modifier
            .size(68.dp)
            .clip(CircleShape)
            .background(c.surfaceVariant)
            .pointerInput(d) {
                detectTapGestures(
                    onPress = { Sounds.key(ctx, d[0]) },
                    onTap = { onTap() },
                    onLongPress = { onLong?.invoke() },
                )
            },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(d, fontSize = 28.sp, color = c.onSurface)
        Text(
            l,
            fontSize = 10.sp,
            color = c.onSurfaceVariant,
            letterSpacing = 1.sp,
            modifier = Modifier.height(12.dp),
        )
    }
}
