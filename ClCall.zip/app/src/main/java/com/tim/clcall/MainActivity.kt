package com.tim.clcall

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf

class MainActivity : ComponentActivity() {
    private val tick = mutableIntStateOf(0)
    private val pending = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT),
        )
        Sounds.init(this)
        Notifs.channels(this)
        readIntent(intent)
        setContent {
            ClTheme {
                ClApp(tick.intValue, pending)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        tick.intValue = tick.intValue + 1
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readIntent(intent)
    }

    private fun readIntent(i: Intent?) {
        if (i == null) return
        val d = i.data
        if (d != null && d.scheme == "tel") {
            pending.value = Uri.decode(d.schemeSpecificPart ?: "")
        } else if (i.action == Intent.ACTION_DIAL) {
            pending.value = ""
        }
    }
}
