package com.tim.clcalendar

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import java.time.LocalDate
import java.time.ZoneId

object Reminders {
    private const val CHANNEL = "reminders"

    fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Напоминания", NotificationManager.IMPORTANCE_HIGH)
            )
        }
    }

    private fun code(id: Long): Int = (id % Int.MAX_VALUE).toInt()

    private fun pending(ctx: Context, note: Note): PendingIntent {
        val intent = Intent(ctx, ReminderReceiver::class.java)
            .putExtra("id", note.id)
            .putExtra("text", note.text)
        return PendingIntent.getBroadcast(
            ctx,
            code(note.id),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    fun schedule(ctx: Context, note: Note) {
        if (note.remindMin < 0) return
        val at = LocalDate.ofEpochDay(note.epochDay)
            .atTime(note.remindMin / 60, note.remindMin % 60)
            .atZone(ZoneId.systemDefault())
            .toInstant()
            .toEpochMilli()
        if (at <= System.currentTimeMillis()) return

        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = pending(ctx, note)
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun cancel(ctx: Context, note: Note) {
        ctx.getSystemService(AlarmManager::class.java).cancel(pending(ctx, note))
    }

    fun rescheduleAll(ctx: Context, notes: List<Note>) {
        ensureChannel(ctx)
        notes.forEach { schedule(ctx, it) }
    }

    fun show(ctx: Context, id: Long, text: String) {
        val open = PendingIntent.getActivity(
            ctx,
            0,
            Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setColor(0xFFF28C28.toInt())
            .setContentTitle("ClCalendar")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_EVENT)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(code(id), n)
    }
}
