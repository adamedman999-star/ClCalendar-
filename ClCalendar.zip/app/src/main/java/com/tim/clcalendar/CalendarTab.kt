package com.tim.clcalendar

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.*
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.time.temporal.ChronoUnit

private const val PAGES = 2400
private const val START = 1200

enum class ViewMode(val label: String) {
    MONTH("Месяц"),
    WEEK("Неделя"),
    DAY("День"),
}

@Composable
fun CalendarTab(state: NotesState) {
    val c = MaterialTheme.colorScheme
    val today = remember { LocalDate.now() }
    val base = remember { YearMonth.from(today) }
    val pager = rememberPagerState(initialPage = START, pageCount = { PAGES })
    val scope = rememberCoroutineScope()
    var selected by remember { mutableStateOf(today) }
    var mode by remember { mutableStateOf(ViewMode.MONTH) }
    var sheetOpen by remember { mutableStateOf(false) }

    // свайп месяцев -> выбранная дата
    LaunchedEffect(pager.settledPage) {
        val m = base.plusMonths((pager.settledPage - START).toLong())
        if (YearMonth.from(selected) != m) selected = if (m == base) today else m.atDay(1)
    }
    // выбранная дата -> страница месяцев
    LaunchedEffect(selected) {
        val target = START + ChronoUnit.MONTHS.between(base, YearMonth.from(selected)).toInt()
        if (pager.currentPage != target) pager.animateScrollToPage(target)
    }

    val shownMonth = if (mode == ViewMode.MONTH) {
        base.plusMonths((pager.currentPage - START).toLong())
    } else {
        YearMonth.from(selected)
    }
    val title = shownMonth.month.getDisplayName(TextStyle.FULL_STANDALONE, RU)
        .replaceFirstChar { it.uppercase() } + " " + shownMonth.year

    val step: (Int) -> Unit = { dir ->
        when (mode) {
            ViewMode.MONTH -> scope.launch { pager.animateScrollToPage(pager.currentPage + dir) }
            ViewMode.WEEK -> selected = selected.plusWeeks(dir.toLong())
            ViewMode.DAY -> selected = selected.plusDays(dir.toLong())
        }
    }

    Column(Modifier.fillMaxSize()) {
        // Логотип и кнопка «+»
        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                buildAnnotatedString {
                    withStyle(SpanStyle(color = ClOrange)) { append("Cl") }
                    append("Calendar")
                },
                fontSize = 30.sp,
                fontWeight = FontWeight.ExtraBold,
                color = c.onBackground,
            )
            Box(
                Modifier
                    .size(52.dp)
                    .shadow(6.dp, CircleShape)
                    .clip(CircleShape)
                    .background(ClBrick)
                    .clickable { sheetOpen = true },
                contentAlignment = Alignment.Center,
            ) {
                Text("+", color = Color.White, fontSize = 30.sp)
            }
        }

        // Месяц и стрелки
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Box(
                Modifier
                    .shadow(6.dp, RoundedCornerShape(20.dp))
                    .clip(RoundedCornerShape(20.dp))
                    .background(c.surface)
                    .clickable { selected = today }
                    .padding(horizontal = 18.dp, vertical = 8.dp)
            ) {
                Text(
                    title,
                    fontFamily = FontFamily.Serif,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Medium,
                    color = c.onSurface,
                )
            }
            Row {
                Arrow("‹") { step(-1) }
                Arrow("›") { step(1) }
            }
        }

        // Месяц / Неделя / День
        Box(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 6.dp)
                .shadow(4.dp, RoundedCornerShape(16.dp))
                .clip(RoundedCornerShape(16.dp))
                .background(c.surfaceVariant)
                .padding(4.dp)
        ) {
            Row {
                ViewMode.values().forEach { m ->
                    val sel = m == mode
                    Box(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (sel) c.surface else Color.Transparent)
                            .clickable { mode = m }
                            .padding(vertical = 9.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            m.label,
                            fontSize = 15.sp,
                            fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (sel) c.onSurface else c.onSurfaceVariant,
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(6.dp))

        when (mode) {
            ViewMode.MONTH -> MonthView(
                state = state,
                pager = pager,
                base = base,
                today = today,
                selected = selected,
                onSelect = { selected = it },
                onEventClick = { sheetOpen = true },
            )
            ViewMode.WEEK -> WeekView(
                state = state,
                selected = selected,
                today = today,
                onPick = {
                    selected = it
                    mode = ViewMode.DAY
                },
            )
            ViewMode.DAY -> DayView(
                state = state,
                selected = selected,
                onEventClick = { sheetOpen = true },
            )
        }
    }

    if (sheetOpen) {
        NoteSheet(day = selected, state = state, onDismiss = { sheetOpen = false })
    }
}

// ---------- Месяц ----------

@Composable
private fun MonthView(
    state: NotesState,
    pager: PagerState,
    base: YearMonth,
    today: LocalDate,
    selected: LocalDate,
    onSelect: (LocalDate) -> Unit,
    onEventClick: () -> Unit,
) {
    val c = MaterialTheme.colorScheme
    val notes = notesOf(state, selected)

    Column(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(c.surfaceVariant)
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 12.dp, end = 12.dp, top = 10.dp, bottom = 4.dp)
            ) {
                WEEKDAYS.forEachIndexed { i, name ->
                    Text(
                        name,
                        modifier = Modifier.weight(1f),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        color = if (i >= 5) weekendColor else c.onSurfaceVariant,
                        fontSize = 12.sp,
                    )
                }
            }
            HorizontalPager(
                state = pager,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
            ) { page ->
                MonthGrid(
                    month = base.plusMonths((page - START).toLong()),
                    today = today,
                    selected = selected,
                    state = state,
                    onDayClick = onSelect,
                )
            }
            Spacer(Modifier.height(8.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(c.outline)
            )
        }

        DayHeader(selected, notes.size)
        if (notes.isEmpty()) {
            EmptyDay()
            Spacer(Modifier.weight(1f))
        } else {
            LazyColumn(Modifier.weight(1f)) {
                items(notes, key = { it.id }) { n -> EventRow(n, onEventClick) }
            }
        }

        val now = java.time.LocalTime.now()
        val next = nextEvent(state, today, now.hour * 60 + now.minute)
        if (next != null) {
            UpcomingCard(next, today) { onSelect(LocalDate.ofEpochDay(next.epochDay)) }
        }
    }
}

@Composable
private fun MonthGrid(
    month: YearMonth,
    today: LocalDate,
    selected: LocalDate,
    state: NotesState,
    onDayClick: (LocalDate) -> Unit,
) {
    val first = month.atDay(1)
    val start = first.minusDays((first.dayOfWeek.value - 1).toLong())
    val withNotes = state.notes.map { it.epochDay }.toSet()

    Column(Modifier.fillMaxWidth()) {
        for (row in 0 until 6) {
            Row(Modifier.fillMaxWidth()) {
                for (col in 0 until 7) {
                    val date = start.plusDays((row * 7 + col).toLong())
                    DayCell(
                        modifier = Modifier
                            .weight(1f)
                            .aspectRatio(1.15f),
                        date = date,
                        inMonth = YearMonth.from(date) == month,
                        today = today,
                        selected = selected,
                        hasNotes = date.toEpochDay() in withNotes,
                        onClick = onDayClick,
                    )
                }
            }
        }
    }
}

@Composable
private fun DayCell(
    modifier: Modifier,
    date: LocalDate,
    inMonth: Boolean,
    today: LocalDate,
    selected: LocalDate,
    hasNotes: Boolean,
    onClick: (LocalDate) -> Unit,
) {
    val c = MaterialTheme.colorScheme
    val isSel = date == selected
    val isToday = date == today
    val weekend = date.dayOfWeek == DayOfWeek.SATURDAY || date.dayOfWeek == DayOfWeek.SUNDAY
    val holiday = Holidays.name(date) != null
    val wk = weekendColor
    val hd = holidayColor
    val textColor = when {
        isSel -> Color.White
        !inMonth -> c.onSurfaceVariant.copy(alpha = 0.55f)
        weekend -> wk
        holiday -> hd
        else -> c.onSurface
    }

    Box(modifier.padding(2.dp), contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .fillMaxHeight()
                .aspectRatio(1f)
                .clip(CircleShape)
                .background(if (isSel) ClOrange else Color.Transparent)
                .then(
                    if (isToday && !isSel) Modifier.border(1.5.dp, ClOrange, CircleShape)
                    else Modifier
                )
                .clickable { onClick(date) },
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    date.dayOfMonth.toString(),
                    fontSize = 16.sp,
                    fontWeight = if (isSel || isToday) FontWeight.Bold else FontWeight.Normal,
                    color = textColor,
                )
                Box(
                    Modifier
                        .padding(top = 1.dp)
                        .size(4.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                !hasNotes -> Color.Transparent
                                isSel -> Color.White
                                else -> ClOrange
                            }
                        )
                )
            }
        }
    }
}

// ---------- Неделя ----------

@Composable
private fun WeekView(
    state: NotesState,
    selected: LocalDate,
    today: LocalDate,
    onPick: (LocalDate) -> Unit,
) {
    val c = MaterialTheme.colorScheme
    val monday = selected.minusDays((selected.dayOfWeek.value - 1).toLong())
    val sunday = monday.plusDays(6)
    val total = (0..6).sumOf { notesOf(state, monday.plusDays(it.toLong())).size }
    val range = monday.dayOfMonth.toString() + " – " +
        sunday.format(DateTimeFormatter.ofPattern("d MMMM", RU))

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(range, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = c.onBackground)
            Text(eventsCount(total), fontSize = 14.sp, color = c.onSurfaceVariant)
        }
        LazyColumn(Modifier.weight(1f)) {
            items(7) { i ->
                val d = monday.plusDays(i.toLong())
                val notes = notesOf(state, d)
                val isToday = d == today
                Column {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(c.outline)
                    )
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .background(if (d == selected) c.surfaceVariant else Color.Transparent)
                            .clickable { onPick(d) }
                            .padding(horizontal = 20.dp, vertical = 10.dp),
                    ) {
                        Column(Modifier.width(52.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                WEEKDAYS[i],
                                fontSize = 12.sp,
                                color = if (i >= 5) weekendColor else c.onSurfaceVariant,
                            )
                            Spacer(Modifier.height(4.dp))
                            Box(
                                Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(if (isToday) ClOrange else Color.Transparent),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text(
                                    d.dayOfMonth.toString(),
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isToday) Color.White else c.onBackground,
                                )
                            }
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            if (notes.isEmpty()) {
                                Text(
                                    "Нет событий",
                                    fontSize = 14.sp,
                                    color = c.onSurfaceVariant,
                                    modifier = Modifier.padding(top = 22.dp),
                                )
                            } else {
                                notes.forEach { n ->
                                    Row(
                                        Modifier.padding(vertical = 3.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) {
                                        Box(
                                            Modifier
                                                .width(3.dp)
                                                .height(32.dp)
                                                .clip(RoundedCornerShape(2.dp))
                                                .background(barColor(n))
                                        )
                                        Spacer(Modifier.width(8.dp))
                                        Column {
                                            Text(
                                                n.text,
                                                fontSize = 15.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = c.onBackground,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                            )
                                            Text(
                                                if (n.remindMin >= 0) fmt(n.remindMin) else "Весь день",
                                                fontSize = 12.sp,
                                                color = c.onSurfaceVariant,
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------- День ----------

@Composable
private fun DayView(
    state: NotesState,
    selected: LocalDate,
    onEventClick: () -> Unit,
) {
    val c = MaterialTheme.colorScheme
    val notes = notesOf(state, selected)
    val allDay = notes.filter { it.remindMin < 0 }
    val timed = notes.filter { it.remindMin >= 0 }
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = 7)

    Column(Modifier.fillMaxSize()) {
        DayHeader(selected, notes.size)
        if (allDay.isNotEmpty()) {
            Text(
                "Весь день",
                fontSize = 12.sp,
                color = c.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 20.dp),
            )
            allDay.forEach { EventRow(it, onEventClick) }
            Spacer(Modifier.height(4.dp))
        }
        LazyColumn(Modifier.weight(1f), state = listState) {
            items(24) { h ->
                val inHour = timed.filter { it.remindMin / 60 == h }
                Column {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .padding(start = 72.dp)
                            .height(1.dp)
                            .background(c.outline)
                    )
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .heightIn(min = 56.dp)
                            .padding(start = 20.dp)
                    ) {
                        Text(
                            "%02d:00".format(h),
                            modifier = Modifier
                                .width(52.dp)
                                .padding(top = 6.dp),
                            fontSize = 12.sp,
                            color = c.onSurfaceVariant,
                        )
                        Column(
                            Modifier
                                .weight(1f)
                                .padding(end = 20.dp, top = 4.dp, bottom = 4.dp)
                        ) {
                            inHour.forEach { n ->
                                val col = barColor(n)
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 2.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(col.copy(alpha = 0.14f))
                                        .clickable(onClick = onEventClick)
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Box(
                                        Modifier
                                            .width(3.dp)
                                            .height(30.dp)
                                            .clip(RoundedCornerShape(2.dp))
                                            .background(col)
                                    )
                                    Spacer(Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            n.text,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = c.onBackground,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                        Text(fmt(n.remindMin), fontSize = 12.sp, color = c.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
