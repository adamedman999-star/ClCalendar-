package com.tim.clcall

import android.content.Intent
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.TelecomManager

class ClInCallService : InCallService() {

    private val callback = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) {
            CallHolder.states[call] = state
            if (state == Call.STATE_SELECT_PHONE_ACCOUNT) autoSelect(call)
            Notifs.update(this@ClInCallService)
        }
    }

    @Suppress("DEPRECATION")
    override fun onCallAdded(call: Call) {
        call.registerCallback(callback)
        CallHolder.service = this
        CallHolder.infos[call] = buildInfo(call)
        CallHolder.states[call] = call.state
        CallHolder.calls.add(call)
        syncAudio(callAudioState)
        if (call.state == Call.STATE_SELECT_PHONE_ACCOUNT) autoSelect(call)
        Notifs.update(this)
        try {
            startActivity(
                Intent(this, InCallActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
        } catch (_: Exception) {
        }
    }

    override fun onCallRemoved(call: Call) {
        call.unregisterCallback(callback)
        CallHolder.calls.remove(call)
        CallHolder.states.remove(call)
        CallHolder.infos.remove(call)
        Notifs.update(this)
    }

    @Suppress("DEPRECATION")
    override fun onCallAudioStateChanged(audioState: CallAudioState?) {
        syncAudio(audioState)
    }

    override fun onDestroy() {
        if (CallHolder.service === this) CallHolder.service = null
        super.onDestroy()
    }

    private fun syncAudio(s: CallAudioState?) {
        CallHolder.muted = s?.isMuted ?: false
        CallHolder.speaker = s?.route == CallAudioState.ROUTE_SPEAKER
    }

    private fun autoSelect(call: Call) {
        try {
            val h = getSystemService(TelecomManager::class.java).callCapablePhoneAccounts.firstOrNull()
            if (h != null) call.phoneAccountSelected(h, false)
        } catch (_: Exception) {
        }
    }

    private fun buildInfo(call: Call): CallInfo {
        val number = call.details.handle?.schemeSpecificPart ?: ""
        val who = Repo.lookup(this, number)
        val name = who.name ?: call.details.callerDisplayName?.takeIf { it.isNotBlank() }
        val carrier = Carriers.forAccount(this, call.details.accountHandle?.id)
        return CallInfo(name, number, who.label, carrier)
    }
}
