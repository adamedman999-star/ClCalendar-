package com.tim.clcall

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class AppTab(val label: String, val icon: Int) {
    HOME("Главная", R.drawable.ic_home),
    KEYPAD("Клавиатура", R.drawable.ic_dialpad),
    PROFILE("Профиль", R.drawable.ic_user),
}

@Composable
fun ClApp(tick: Int, pending: MutableState<String?>) {
    val ctx = LocalContext.current
    val c = MaterialTheme.colorScheme
    val profile = remember { ProfileState(ctx) }
    var tab by remember { mutableStateOf(AppTab.HOME) }
    var number by remember { mutableStateOf("") }
    var ver by remember { mutableIntStateOf(0) }
    var calls by remember { mutableStateOf(emptyList<CallEntry>()) }
    var contacts by remember { mutableStateOf(emptyList<ContactEntry>()) }
    var simFor by remember { mutableStateOf<String?>(null) }

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { ver++ }
    val roleLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { ver++ }

    val core = remember(tick, ver) { Perms.core(ctx) }
    val isDefault = remember(tick, ver) { Dialer.isDefault(ctx) }

    LaunchedEffect(Unit) {
        if (!Perms.all(ctx)) permLauncher.launch(Perms.list)
    }
    LaunchedEffect(tick, ver) {
        val loaded = withContext(Dispatchers.IO) {
            Pair(Repo.loadCalls(ctx), Repo.loadContacts(ctx))
        }
        calls = loaded.first
        contacts = loaded.second
    }
    LaunchedEffect(pending.value) {
        pending.value?.let {
            number = it
            tab = AppTab.KEYPAD
            pending.value = null
        }
    }

    val askPerms: () -> Unit = { permLauncher.launch(Perms.list) }
    val setDefault: () -> Unit = {
        Dialer.roleIntent(ctx)?.let { roleLauncher.launch(it) }
    }
    val call: (String) -> Unit = { n ->
        if (!Perms.has(ctx, Manifest.permission.CALL_PHONE)) {
            permLauncher.launch(Perms.list)
        } else {
            val acc = Dialer.pickableAccounts(ctx)
            if (acc.size > 1) simFor = n else Dialer.place(ctx, n, null)
        }
    }

    Scaffold(
        containerColor = c.background,
        contentWindowInsets = WindowInsets(0.dp, 0.dp, 0.dp, 0.dp),
        bottomBar = { NavBar(tab) { tab = it } },
    ) { padding ->
        Box(
            Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            when (tab) {
                AppTab.HOME -> HomeTab(
                    calls = calls,
                    contacts = contacts,
                    corePerms = core,
                    isDefault = isDefault,
                    onAskPerms = askPerms,
                    onSetDefault = setDefault,
                    onRefresh = { ver++ },
                    onCall = call,
                    onToKeypad = {
                        number = it
                        tab = AppTab.KEYPAD
                    },
                )
                AppTab.KEYPAD -> KeypadTab(
                    number = number,
                    onNumber = { number = it },
                    contacts = contacts,
                    onCall = call,
                )
                AppTab.PROFILE -> ProfileTab(
                    profile = profile,
                    calls = calls,
                    contacts = contacts,
                    corePerms = core,
                    isDefault = isDefault,
                    onAskPerms = askPerms,
                    onSetDefault = setDefault,
                )
            }
        }
    }

    simFor?.let { n ->
        val accs = remember(n) { Dialer.pickableAccounts(ctx) }
        AlertDialog(
            onDismissRequest = { simFor = null },
            confirmButton = {},
            containerColor = c.surface,
            title = { Text("Выберите SIM") },
            text = {
                Column {
                    accs.forEachIndexed { i, h ->
                        TextButton(onClick = {
                            Sounds.click(ctx)
                            simFor = null
                            Dialer.place(ctx, n, h)
                        }) {
                            Text(Dialer.simLabel(ctx, h, i), fontSize = 16.sp)
                        }
                    }
                }
            },
        )
    }
}

@Composable
private fun NavBar(current: AppTab, onPick: (AppTab) -> Unit) {
    val c = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    Column(Modifier.background(c.surface)) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(c.outline)
        )
        Row(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .height(64.dp)
        ) {
            AppTab.values().forEach { t ->
                val sel = t == current
                val col = if (sel) c.primary else c.onSurfaceVariant
                Column(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable {
                            Sounds.click(ctx)
                            onPick(t)
                        },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Ico(t.icon, 24.dp, col)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        t.label,
                        fontSize = 11.sp,
                        color = col,
                        fontWeight = if (sel) FontWeight.Medium else FontWeight.Normal,
                    )
                }
            }
        }
    }
}
