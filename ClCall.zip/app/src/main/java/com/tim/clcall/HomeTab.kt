package com.tim.clcall

import android.provider.CallLog
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private val RU: Locale = Locale.forLanguageTag("ru")

private sealed class LogRow {
    data class Head(val title: String) : LogRow()
    data class Item(val entry: CallEntry) : LogRow()
}

private fun dayLabel(d: LocalDate): String {
    val t = LocalDate.now()
    return when {
        d == t -> "Сегодня"
        d == t.minusDays(1) -> "Вчера"
        d.year == t.year -> d.format(DateTimeFormatter.ofPattern("d MMMM", RU))
        else -> d.format(DateTimeFormatter.ofPattern("d MMMM yyyy", RU))
    }
}

private fun buildRows(calls: List<CallEntry>): List<LogRow> {
    val out = ArrayList<LogRow>()
    val zone = ZoneId.systemDefault()
    var last: LocalDate? = null
    for (e in calls) {
        val d = Instant.ofEpochMilli(e.date).atZone(zone).toLocalDate()
        if (d != last) {
            out.add(LogRow.Head(dayLabel(d)))
            last = d
        }
        out.add(LogRow.Item(e))
    }
    return out
}

@Composable
fun HomeTab(
    calls: List<CallEntry>,
    contacts: List<ContactEntry>,
    corePerms: Boolean,
    isDefault: Boolean,
    onAskPerms: () -> Unit,
    onSetDefault: () -> Unit,
    onRefresh: () -> Unit,
    onCall: (String) -> Unit,
    onToKeypad: (String) -> Unit,
) {
    val c = MaterialTheme.colorScheme
    var query by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    val rows = remember(calls) { buildRows(calls) }
    val q = query.trim()
    val qd = digitsOf(q)
    val found = remember(q, contacts) {
        if (q.isEmpty()) emptyList()
        else contacts.filter {
            it.name.contains(q, true) || (qd.isNotEmpty() && digitsOf(it.number).contains(qd))
        }.take(50)
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(start = 20.dp, end = 16.dp, top = 8.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Logo()
            Box {
                CircleBtn(R.drawable.ic_dots, c.surfaceVariant, c.onSurface) { menu = true }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Обновить журнал") },
                        onClick = {
                            menu = false
                            onRefresh()
                        },
                    )
                    if (!isDefault) {
                        DropdownMenuItem(
                            text = { Text("Сделать основным для звонков") },
                            onClick = {
                                menu = false
                                onSetDefault()
                            },
                        )
                    }
                }
            }
        }

        Row(
            Modifier
                .padding(horizontal = 16.dp)
                .fillMaxWidth()
                .height(48.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(c.surfaceVariant)
                .border(1.dp, c.outline, RoundedCornerShape(24.dp))
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Ico(R.drawable.ic_search, 20.dp, c.onSurfaceVariant)
            Spacer(Modifier.width(10.dp))
            Box(Modifier.weight(1f)) {
                if (query.isEmpty()) {
                    Text("Поиск контактов", color = c.onSurfaceVariant, fontSize = 16.sp)
                }
                BasicTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    textStyle = TextStyle(color = c.onSurface, fontSize = 16.sp),
                    cursorBrush = SolidColor(ClOrange),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            if (query.isNotEmpty()) {
                Text(
                    "✕",
                    color = c.onSurfaceVariant,
                    modifier = Modifier
                        .clClick { query = "" }
                        .padding(4.dp),
                )
            }
        }

        LazyColumn(
            Modifier
                .weight(1f)
                .padding(horizontal = 16.dp)
        ) {
            if (!corePerms) {
                item {
                    Banner("Нужен доступ к журналу звонков, контактам и телефону.", "Разрешить", onAskPerms)
                }
            }
            if (!isDefault) {
                item {
                    Banner(
                        "Сделайте ClCall основным приложением для звонков — тогда появятся свои экраны звонка.",
                        "Назначить",
                        onSetDefault,
                    )
                }
            }
            if (q.isEmpty()) {
                if (rows.isEmpty()) {
                    item { EmptyState("Звонков пока нет", "Наберите номер на вкладке «Клавиатура».") }
                }
                items(rows) { r ->
                    when (r) {
                        is LogRow.Head -> DayChip(r.title)
                        is LogRow.Item -> CallCard(r.entry, onCall, onToKeypad)
                    }
                }
            } else {
                if (found.isEmpty()) {
                    item { EmptyState("Ничего не найдено", "Попробуйте другое имя или номер.") }
                }
                items(found) { ct -> ContactCard(ct, onCall, onToKeypad) }
            }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

@Composable
private fun Banner(text: String, action: String, onClick: () -> Unit) {
    val c = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .padding(top = 12.dp)
            .fillMaxWidth()
            .clip(shape)
            .background(c.surfaceVariant)
            .border(1.dp, c.outline, shape)
            .padding(start = 14.dp, top = 6.dp, bottom = 6.dp, end = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text, modifier = Modifier.weight(1f), fontSize = 13.sp, color = c.onSurface)
        Text(
            action,
            color = ClOrange,
            fontWeight = FontWeight.Medium,
            modifier = Modifier
                .clClick(onClick)
                .padding(10.dp),
        )
    }
}

@Composable
private fun EmptyState(title: String, sub: String) {
    val c = MaterialTheme.colorScheme
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(title, fontSize = 17.sp, color = c.onBackground)
        Spacer(Modifier.height(4.dp))
        Text(sub, fontSize = 14.sp, color = c.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}

@Composable
private fun DayChip(title: String) {
    val c = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(16.dp)
    Box(
        Modifier
            .padding(top = 14.dp, bottom = 8.dp)
            .clip(shape)
            .background(c.surface)
            .border(1.dp, c.outline, shape)
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        Text(title, fontFamily = FontFamily.Serif, fontSize = 15.sp, color = c.onSurface)
    }
}

@Composable
private fun CallCard(e: CallEntry, onCall: (String) -> Unit, onToKeypad: (String) -> Unit) {
    val c = MaterialTheme.colorScheme
    val missed = missedColor
    val shape = RoundedCornerShape(18.dp)
    val glyph: String
    val status: String
    val col: Color
    when (e.type) {
        CallLog.Calls.INCOMING_TYPE -> { glyph = "↙"; status = "Входящий"; col = ClGreen }
        CallLog.Calls.OUTGOING_TYPE -> { glyph = "↗"; status = "Исходящий"; col = c.onSurfaceVariant }
        CallLog.Calls.MISSED_TYPE -> { glyph = "↙"; status = "Пропущенный"; col = missed }
        CallLog.Calls.REJECTED_TYPE -> { glyph = "✕"; status = "Отклонённый"; col = c.onSurfaceVariant }
        CallLog.Calls.BLOCKED_TYPE -> { glyph = "⊘"; status = "Заблокированный"; col = c.onSurfaceVariant }
        CallLog.Calls.VOICEMAIL_TYPE -> { glyph = "●"; status = "Голосовая почта"; col = c.onSurfaceVariant }
        else -> { glyph = "•"; status = "Звонок"; col = c.onSurfaceVariant }
    }
    val time = remember(e.date) {
        Instant.ofEpochMilli(e.date).atZone(ZoneId.systemDefault())
            .format(DateTimeFormatter.ofPattern("HH:mm"))
    }
    val details = listOfNotNull(e.label, e.carrier, time).joinToString(" · ")
    val title = e.name ?: pretty(e.number).ifBlank { "Неизвестный номер" }

    Row(
        Modifier
            .padding(bottom = 8.dp)
            .fillMaxWidth()
            .clip(shape)
            .background(c.surface)
            .border(1.dp, c.outline, shape)
            .clClick { if (e.number.isNotBlank()) onToKeypad(e.number) }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Avatar(e.name)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                color = c.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(glyph, color = col, fontSize = 13.sp)
                Spacer(Modifier.width(4.dp))
                Text(status, color = col, fontSize = 13.sp)
            }
            Text(
                details,
                fontSize = 12.sp,
                color = c.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (e.number.isNotBlank()) {
            Spacer(Modifier.width(8.dp))
            CircleBtn(R.drawable.ic_phone, c.surfaceVariant, c.onSurface, 40.dp, 18.dp) {
                onCall(e.number)
            }
        }
    }
}

@Composable
private fun ContactCard(ct: ContactEntry, onCall: (String) -> Unit, onToKeypad: (String) -> Unit) {
    val c = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier
            .padding(top = 8.dp)
            .fillMaxWidth()
            .clip(shape)
            .background(c.surface)
            .border(1.dp, c.outline, shape)
            .clClick { onToKeypad(ct.number) }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Avatar(ct.name)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                ct.name,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                color = c.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                listOfNotNull(ct.label, pretty(ct.number)).joinToString(" · "),
                fontSize = 13.sp,
                color = c.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.width(8.dp))
        CircleBtn(R.drawable.ic_phone, c.surfaceVariant, c.onSurface, 40.dp, 18.dp) {
            onCall(ct.number)
        }
    }
}
