package com.tim.clcalendar

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val ClOrange = Color(0xFFD97757)
val WeekendRed = Color(0xFFE5484D)
val HolidayRed = WeekendRed.copy(alpha = 0.55f)

private val LightColors = lightColorScheme(
    primary = ClOrange,
    onPrimary = Color.White,
    background = Color(0xFFF4F2EB),
    onBackground = Color(0xFF1F1E1D),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1F1E1D),
    surfaceVariant = Color(0xFFF0EEE6),
    onSurfaceVariant = Color(0xFF6B6963),
    outline = Color(0xFFD6D2C4),
)

private val DarkColors = darkColorScheme(
    primary = ClOrange,
    onPrimary = Color.White,
    background = Color(0xFF141413),
    onBackground = Color(0xFFFAF9F5),
    surface = Color(0xFF211F1E),
    onSurface = Color(0xFFFAF9F5),
    surfaceVariant = Color(0xFF2A2927),
    onSurfaceVariant = Color(0xFFA8A69E),
    outline = Color(0xFF45423E),
)

@Composable
fun ClTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content,
    )
}
