package com.tim.clcall

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val ClOrange = Color(0xFFF28C28)
val ClBrick = Color(0xFFB8442A)
val ClGreen = Color(0xFF3F8F5A)

val missedColor: Color
    @Composable get() = if (isSystemInDarkTheme()) Color(0xFFE5614A) else Color(0xFFE02424)

private val LightColors = lightColorScheme(
    primary = ClBrick,
    onPrimary = Color.White,
    background = Color(0xFFFBFAF6),
    onBackground = Color(0xFF1E1D1B),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1E1D1B),
    surfaceVariant = Color(0xFFF3F1EA),
    onSurfaceVariant = Color(0xFF8E8B84),
    outline = Color(0xFFE6E2D8),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFCB5A3E),
    onPrimary = Color.White,
    background = Color(0xFF121210),
    onBackground = Color(0xFFF2EFEA),
    surface = Color(0xFF1C1B19),
    onSurface = Color(0xFFF2EFEA),
    surfaceVariant = Color(0xFF232120),
    onSurfaceVariant = Color(0xFF9C978F),
    outline = Color(0xFF2F2D2A),
)

@Composable
fun ClTheme(forceDark: Boolean = false, content: @Composable () -> Unit) {
    val dark = forceDark || isSystemInDarkTheme()
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        content = content,
    )
}
