package com.tim.clcalendar

import android.Manifest
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

private val RU: Locale = Locale.forLanguageTag("ru")
private const val PAGES = 2400
private const val START = 1200
private val WEEKDAYS = listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")

private fun fmt(min: Int) = "%02d:%02d".format(min / 60, min % 60)

@Composable
private fun AppHeader() {
    Box(
        Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.primary)
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(R.drawable.ic_header),
                contentDescription = null,
                modifier = Modifier.size(28.dp),
            )
            Spacer(Modifier.width(10.dp))
            Text(
                "ClCalendar",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
            )
        }
    }
}

@Composable
fun CalendarScreen(state: NotesState) {
    val today = remember { LocalDate.now() }
    val base = remember { YearMonth.from(today) }
    val pager = rememberPagerState(initialPage = START, pageCount = { PAGES })
    val scope = rememberCoroutineScope()
    var selected by remember { mutableStateOf<LocalDate?>(null) }
    val current = base.plusMonths((pager.currentPage - START).toLong())
    val title = current.month.getDisplayName(TextStyle.FULL_STANDALONE, RU)
        .replaceFirstChar { it.uppercase() } + " " + current.year

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { AppHeader() },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { selected = today },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White,
                shape = CircleShape,
            ) {
                Text("+", fontSize = 28.sp)
            }
        },
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            ) {
                Column(Modifier.padding(horizontal = 8.dp, vertical = 8.dp)) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(
                            title,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier
                                .padding(start = 8.dp)
                                .clickable { scope.launch { pager.animateScrollToPage(START) } },
                        )
                        Row {
                            TextButton(onClick = {
                                scope.launch { pager.animateScrollToPage(pager.currentPage - 1) }
                            }) { Text("‹", fontSize = 28.sp) }
                            TextButton(onClick = {
                                scope.launch { pager.animateScrollToPage(pager.currentPage + 1) }
                            }) { Text("›", fontSize = 28.sp) }
                        }
                    }

                    Row(Modifier.fillMaxWidth()) {
                        WEEKDAYS.forEachIndexed { i, name ->
                            Text(
                                name,
                                modifier = Modifier.weight(1f),
                                textAlign = TextAlign.Center,
                                color = if (i >= 5) WeekendRed else MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 13.sp,
                            )
                        }
                    }
                    Spacer(Modifier.height(4.dp))

                    HorizontalPager(state = pager, modifier = Modifier.fillMaxWidth()) { page ->
                        MonthGrid(
                            month = base.plusMonths((page - START).toLong()),
                            today = today,
                            state = state,
                            onDayClick = { selected = it },
                        )
                    }
                }
            }
        }
    }

    selected?.let { day ->
        NoteSheet(day = day, state = state, onDismiss = { selected = null })
    }
}

@Composable
private fun MonthGrid(
    month: YearMonth,
    today: LocalDate,
    state: NotesState,
    onDayClick: (LocalDate) -> Unit,
) {
    val offset = month.atDay(1).dayOfWeek.value - 1
    val length = month.lengthOfMonth()
    val daysWithNotes = state.notes.map { it.epochDay }.toSet()

    Column(Modifier.fillMaxWidth()) {
        for (row in 0 until 6) {
            Row(Modifier.fillMaxWidth()) {
                for (col in 0 until 7) {
                    val dayNum = row * 7 + col - offset + 1
                    val date = if (dayNum in 1..length) month.atDay(dayNum) else null
                    DayCell(
                        modifier = Modifier
                            .weight(1f)
                            .aspectRatio(0.9f),
                        date = date,
                        today = today,
                        hasNotes = date != null && date.toEpochDay() in daysWithNotes,
                        onClick = onDayClick,
                    )
                }
            }
        }
    }
}

@Composable
private fun DayCell(
    modifier: Modifier,
    date: LocalDate?,
    today: LocalDate,
    hasNotes: Boolean,
    onClick: (LocalDate) -> Unit,
) {
    Box(modifier.padding(3.dp), contentAlignment = Alignment.Center) {
        if (date != null) {
            val isToday = date == today
            val primary = MaterialTheme.colorScheme.primary
            val weekend = date.dayOfWeek == DayOfWeek.SATURDAY || date.dayOfWeek == DayOfWeek.SUNDAY
            val holiday = Holidays.name(date) != null
            val textColor = when {
                isToday -> Color.White
                weekend -> WeekendRed
                holiday -> HolidayRed
                else -> MaterialTheme.colorScheme.onSurface
            }
            Box(
                Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (isToday) primary else Color.Transparent)
                    .clickable { onClick(date) },
                contentAlignment = Alignment.Center,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        date.dayOfMonth.toString(),
                        fontSize = 16.sp,
                        fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal,
                        color = textColor,
                    )
                    Box(
                        Modifier
                            .padding(top = 3.dp)
                            .size(5.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    !hasNotes -> Color.Transparent
                                    isToday -> Color.White
                                    else -> primary
                                }
                            )
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NoteSheet(day: LocalDate, state: NotesState, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var text by remember { mutableStateOf("") }
    var remind by remember { mutableStateOf(false) }
    var minutes by remember { mutableStateOf(9 * 60) }
    val dayNotes = state.notes.filter { it.epochDay == day.toEpochDay() }
    val title = day.format(DateTimeFormatter.ofPattern("d MMMM, EEEE", RU))
    val holiday = Holidays.name(day)
    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 16.dp)
                .navigationBarsPadding()
                .imePadding()
        ) {
            Text(
                title,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
            )
            if (holiday != null) {
                Text(holiday, color = WeekendRed, fontSize = 14.sp)
            }
            Spacer(Modifier.height(12.dp))

            if (dayNotes.isEmpty()) {
                Text("Заметок нет", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                LazyColumn(Modifier.heightIn(max = 260.dp)) {
                    items(dayNotes, key = { it.id }) { note ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    note.text,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontSize = 16.sp,
                                )
                                if (note.remindMin >= 0) {
                                    Text(
                                        "🔔 " + fmt(note.remindMin),
                                        color = MaterialTheme.colorScheme.primary,
                                        fontSize = 13.sp,
                                    )
                                }
                            }
                            TextButton(onClick = { state.remove(note) }) {
                                Text("✕", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = { Text("Новая заметка") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    maxLines = 4,
                )
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = {
                        if (text.isNotBlank()) {
                            state.add(day, text, if (remind) minutes else -1)
                            text = ""
                            remind = false
                        }
                    },
                    shape = RoundedCornerShape(16.dp),
                ) { Text("+", fontSize = 20.sp) }
            }

            Row(
                Modifier.padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Switch(
                    checked = remind,
                    onCheckedChange = { on ->
                        remind = on
                        if (on && Build.VERSION.SDK_INT >= 33 &&
                            ContextCompat.checkSelfPermission(
                                ctx, Manifest.permission.POST_NOTIFICATIONS
                            ) != PackageManager.PERMISSION_GRANTED
                        ) {
                            permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    },
                    colors = SwitchDefaults.colors(
                        checkedTrackColor = MaterialTheme.colorScheme.primary,
                        checkedThumbColor = Color.White,
                    ),
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    "Напомнить в этот день",
                    modifier = Modifier.weight(1f),
                    color = MaterialTheme.colorScheme.onSurface,
                )
                if (remind) {
                    TextButton(onClick = {
                        TimePickerDialog(
                            ctx,
                            { _, h, m -> minutes = h * 60 + m },
                            minutes / 60,
                            minutes % 60,
                            true,
                        ).show()
                    }) {
                        Text(fmt(minutes), fontSize = 16.sp)
                    }
                }
            }
        }
    }
}
