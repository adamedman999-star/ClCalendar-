package com.tim.clcalendar

import java.time.LocalDate

/** Фиксированные российские праздники. Переносы выходных (меняются каждый год) не учитываются. */
object Holidays {
    private val fixed = mapOf(
        (1 to 1) to "Новый год",
        (1 to 2) to "Новогодние каникулы",
        (1 to 3) to "Новогодние каникулы",
        (1 to 4) to "Новогодние каникулы",
        (1 to 5) to "Новогодние каникулы",
        (1 to 6) to "Новогодние каникулы",
        (1 to 7) to "Рождество Христово",
        (1 to 8) to "Новогодние каникулы",
        (2 to 23) to "День защитника Отечества",
        (3 to 8) to "Международный женский день",
        (5 to 1) to "Праздник Весны и Труда",
        (5 to 9) to "День Победы",
        (6 to 12) to "День России",
        (11 to 4) to "День народного единства",
    )

    fun name(date: LocalDate): String? = fixed[date.monthValue to date.dayOfMonth]
}
