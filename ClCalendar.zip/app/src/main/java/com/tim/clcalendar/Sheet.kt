package com.tim.clcalendar

import android.Manifest
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteSheet(day: LocalDate, state: NotesState, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val c = MaterialTheme.colorScheme
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var text by remember { mutableStateOf("") }
    var remind by remember { mutableStateOf(false) }
    var minutes by remember { mutableStateOf(9 * 60) }
    val dayNotes = notesOf(state, day)
    val holiday = Holidays.name(day)
    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = c.surface,
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 16.dp)
                .navigationBarsPadding()
                .imePadding()
        ) {
            Text(
                dayTitle(day),
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                color = c.onSurface,
            )
            if (holiday != null) {
                Text(holiday, color = weekendColor, fontSize = 14.sp)
            }
            Spacer(Modifier.height(12.dp))

            if (dayNotes.isEmpty()) {
                Text("Заметок нет", color = c.onSurfaceVariant)
            } else {
                LazyColumn(Modifier.heightIn(max = 260.dp)) {
                    items(dayNotes, key = { it.id }) { note ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(note.text, color = c.onSurface, fontSize = 16.sp)
                                if (note.remindMin >= 0) {
                                    Text(
                                        "🔔 " + fmt(note.remindMin),
                                        color = ClOrange,
                                        fontSize = 13.sp,
                                    )
                                }
                            }
                            TextButton(onClick = { state.remove(note) }) {
                                Text("✕", color = c.onSurfaceVariant)
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = { Text("Новая заметка") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    maxLines = 4,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = c.primary,
                        cursorColor = c.primary,
                        unfocusedBorderColor = c.outline,
                    ),
                )
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = {
                        if (text.isNotBlank()) {
                            state.add(day, text, if (remind) minutes else -1)
                            text = ""
                            remind = false
                        }
                    },
                    shape = RoundedCornerShape(16.dp),
                ) { Text("+", fontSize = 20.sp) }
            }

            Row(
                Modifier.padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Switch(
                    checked = remind,
                    onCheckedChange = { on ->
                        remind = on
                        if (on && Build.VERSION.SDK_INT >= 33 &&
                            ContextCompat.checkSelfPermission(
                                ctx, Manifest.permission.POST_NOTIFICATIONS
                            ) != PackageManager.PERMISSION_GRANTED
                        ) {
                            permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    },
                    colors = SwitchDefaults.colors(
                        checkedTrackColor = c.primary,
                        checkedThumbColor = Color.White,
                    ),
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    "Напомнить в этот день",
                    modifier = Modifier.weight(1f),
                    color = c.onSurface,
                )
                if (remind) {
                    TextButton(onClick = {
                        TimePickerDialog(
                            ctx,
                            { _, h, m -> minutes = h * 60 + m },
                            minutes / 60,
                            minutes % 60,
                            true,
                        ).show()
                    }) {
                        Text(fmt(minutes), fontSize = 16.sp)
                    }
                }
            }
        }
    }
}
