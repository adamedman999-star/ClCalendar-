package com.tim.clcall

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.app.NotificationCompat

class CallActionReceiver : BroadcastReceiver() {
    companion object {
        const val DECLINE = "com.tim.clcall.DECLINE"
        const val HANGUP = "com.tim.clcall.HANGUP"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val call = CallHolder.primary ?: return
        when (intent.action) {
            DECLINE -> CallHolder.reject(call)
            HANGUP -> CallHolder.hangup(call)
        }
    }
}

object Remind {
    private const val FLAGS = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

    fun schedule(ctx: Context, name: String, number: String, minutes: Int = 15) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            ctx,
            number.hashCode(),
            Intent(ctx, RemindReceiver::class.java)
                .putExtra("name", name)
                .putExtra("number", number),
            FLAGS,
        )
        am.setAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            System.currentTimeMillis() + minutes * 60_000L,
            pi,
        )
    }
}

class RemindReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val name = intent.getStringExtra("name") ?: return
        val number = intent.getStringExtra("number") ?: ""
        Notifs.channels(context)
        val dial = Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", number, null))
            .setClass(context, MainActivity::class.java)
        val open = PendingIntent.getActivity(
            context, number.hashCode(), dial,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val n = NotificationCompat.Builder(context, Notifs.CH_REMIND)
            .setSmallIcon(R.drawable.ic_phone)
            .setColor(0xFFF28C28.toInt())
            .setContentTitle("Перезвонить")
            .setContentText(name)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        context.getSystemService(NotificationManager::class.java).notify(number.hashCode(), n)
    }
}
