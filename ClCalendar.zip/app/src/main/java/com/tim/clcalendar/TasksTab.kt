package com.tim.clcalendar

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.*

@Composable
fun TasksTab(state: TasksState) {
    val c = MaterialTheme.colorScheme
    var text by remember { mutableStateOf("") }
    val doneCount = state.tasks.count { it.done }
    val sorted = state.tasks.sortedBy { it.done }

    Column(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .statusBarsPadding()
                .padding(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 8.dp)
        ) {
            Text("Задачи", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = c.onBackground)
            Text(
                if (state.tasks.isEmpty()) "Пока пусто" else "Выполнено $doneCount из ${state.tasks.size}",
                fontSize = 14.sp,
                color = c.onSurfaceVariant,
            )
        }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                placeholder = { Text("Новая задача") },
                singleLine = true,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = c.primary,
                    cursorColor = c.primary,
                    unfocusedBorderColor = c.outline,
                ),
            )
            Spacer(Modifier.width(8.dp))
            Button(
                onClick = {
                    if (text.isNotBlank()) {
                        state.add(text)
                        text = ""
                    }
                },
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = ClBrick),
            ) { Text("+", fontSize = 20.sp, color = Color.White) }
        }

        LazyColumn(Modifier.weight(1f)) {
            items(sorted, key = { it.id }) { t ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { state.toggle(t) }
                        .padding(horizontal = 20.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier
                            .size(26.dp)
                            .clip(CircleShape)
                            .background(if (t.done) c.primary else Color.Transparent)
                            .border(2.dp, if (t.done) c.primary else c.onSurfaceVariant, CircleShape),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (t.done) Text("✓", color = Color.White, fontSize = 15.sp)
                    }
                    Spacer(Modifier.width(14.dp))
                    Text(
                        t.title,
                        modifier = Modifier.weight(1f),
                        fontSize = 17.sp,
                        color = if (t.done) c.onSurfaceVariant else c.onBackground,
                        textDecoration = if (t.done) TextDecoration.LineThrough else null,
                    )
                    TextButton(onClick = { state.remove(t) }) {
                        Text("✕", color = c.onSurfaceVariant)
                    }
                }
            }
            if (doneCount > 0) {
                item {
                    TextButton(
                        onClick = { state.clearDone() },
                        modifier = Modifier.padding(horizontal = 12.dp),
                    ) { Text("Убрать выполненные", color = c.primary) }
                }
            }
        }
    }
}
